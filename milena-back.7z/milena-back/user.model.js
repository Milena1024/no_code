const { PrimaryGeneratedColumn, Column, Entity } = require('typeorm');

class User {
  constructor() {
    this.id = undefined;
    this.login = undefined;
    this.password = undefined;
  }
}

User.prototype.id = undefined;
User.prototype.login = undefined;
User.prototype.password = undefined;

User = Entity()(User);
User = PrimaryGeneratedColumn()(User);
User = Column({ unique: true })(User);
User = Column()(User);

module.exports = User;