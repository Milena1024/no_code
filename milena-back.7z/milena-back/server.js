const express = require('express');
const bodyParser = require('body-parser');
const { compare } = require('bcrypt');
const bcrypt = require('bcrypt');
const { createConnection, EntitySchema } = require('typeorm');
const cors = require('cors');

const app = express();
const port = 3001;

app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

// const { User } = require('./user.model');

app.use(cors({
  origin: 'http://localhost:3000',
  credentials: true,
}));

const User = new EntitySchema({ //таблица gпользователь
  name: 'User',
  tableName: 'users',
  columns: {//столбы
    id: {
      primary: true,
      type: 'int',
      generated: true,
    },
    login: {
      type: 'varchar',
      unique: true,// не повторятся
    },
    password: {
      type: 'text',
    },
    color: {
      type: 'text',
    },
  },
});

const Contract = new EntitySchema({
  name: 'Contract',
  tableName: 'contracts',
  columns: {
    id: {
      primary: true,
      type: 'int',
      generated: true,
    },
    name: {
      type: 'varchar',
    },
    login: {
      type: 'varchar',
    },
    idStructs: {
      type: 'json',
      nullable: true,
    },
  },
});

const Struct = new EntitySchema({
  name: 'Struct',
  tableName: 'structs',
  columns: {
    id: {
      primary: true,
      type: 'int',
      generated: true,
    },
    name_Contract: {
      type: 'varchar',
    },
    login: {
      type: 'varchar',
    },
    name: {
      type: 'varchar',
    },
    numElements: {
      type: 'int',
    },
    types: {
      type: 'simple-array', // Изменен тип на 'simple-array' для хранения массива строк
      elementType: 'string', // Указываем тип элементов в массиве как 'string'
      nullable: true,
    },
    elementNames: {
      type: 'simple-array', // Изменен тип на 'simple-array' для хранения массива строк
      elementType: 'string', // Указываем тип элементов в массиве как 'string'
      nullable: true,
    },
    typeMapping: {
      type: 'varchar',
    },
    nameMapping: {
      type: 'varchar',
    },
  },
});

const Function = new EntitySchema({
  name: 'Function',
  tableName: 'functions',
  columns: {
    id: {
      primary: true,
      type: 'int',
      generated: true,
    },
    name: {
      type: 'varchar',
    },
    login: {
      type: 'varchar',
    },
    name_Contract: {
      type: 'varchar',
    },
    text: {
      type: 'text',
    },
  },
});

// Создание подключения к базе данных
createConnection({
  type: 'postgres',
  host: 'localhost',
  port: 5432,
  username: 'username',
  password: 'password',
  database: 'milena_pr',
  synchronize: true,
  logging: true,
  entities: [User, Contract, Struct, Function], //таблицы
})
  .then(async (connection) => {

    // Маршруты для регистрации и аутентификации
    app.post('/login', async (req, res) => {
      const { login, password } = req.body;

      const userRepository = connection.getRepository('User'); // подключение таблица 

      // Проверка наличия пользователя с таким логином
      const existingUser = await userRepository.findOne({ where: { login } });

      if (!existingUser) {
        return res.status(400).json({ message: 'Неправильный логин или пароль' });
      }

      const passCompare = await compare(password, existingUser.password);

      if (!passCompare) {
        return res.status(400).json({ message: 'Неправильный логин или пароль' });
      }

      return res.json({ message: 'Успешная аутентификация', user: req.user });
    });
    // Оставляем только один обработчик для маршрута '/add_struct'
    app.post('/add_struct', async (req, res) => {
      try {
        const { name_Contract, login, name, numElements, types, elementNames, typeMapping, nameMapping } = req.body;

        const structRepository = connection.getRepository('Struct');

        // Проверяем, существует ли запись с такими же значениями name_Contract, login и name
        const existingStruct = await structRepository.findOne({
          where: {
            name_Contract: name_Contract,
            login: login,
            name: name,
          },
        });

        if (existingStruct) {
          // Если запись уже существует, отправляем сообщение об ошибке
          return res.status(400).json({ message: 'Структура с такими параметрами уже существует' });
        }

        // Создаем новую сущность структуры
        const newStruct = structRepository.create();
        newStruct.name_Contract = name_Contract;
        newStruct.login = login;
        newStruct.name = name;
        newStruct.types = []; // Присвоить пустой массив
        newStruct.elementNames = []; // Присвоить пустой массив
        newStruct.numElements = numElements;
        newStruct.typeMapping = typeMapping;
        newStruct.nameMapping = nameMapping;

        // Сохраняем новую структуру в базе данных
        await structRepository.save(newStruct);

        return res.json({ message: 'Структура успешно добавлена' });
      } catch (error) {
        console.error('Ошибка при добавлении структуры:', error);
        return res.status(500).json({ message: 'Не удалось добавить структуру' });
      }
    });
    // Заполнение элементов структуры
    app.post('/add_element_struct', async (req, res) => {
      try {
        const { name_Contract, login, name, types, elementNames } = req.body;

        // Найти существующую структуру по заданным параметрам
        const structRepository = connection.getRepository('Struct');
        const existingStruct = await structRepository.findOne({
          where: { name_Contract, login, name },
        });

        if (existingStruct) {
          // Если структура существует, добавляем новые значения к ней
          existingStruct.types.push(types);
          existingStruct.elementNames.push(elementNames);

          // Сохраняем обновленную структуру в базе данных
          await structRepository.save(existingStruct);

          return res.json({ message: 'Элементы структуры успешно добавлены' });
        } else {
          return res.status(404).json({ message: 'Структура не найдена' });
        }
      } catch (error) {
        console.error('Ошибка при добавлении элементов структуры:', error);
        return res.status(500).json({ message: 'Не удалось добавить элементы структуры' });
      }
    });
    // Добавьте следующий код после определения других маршрутов и перед app.listen:

    // Просмотр записей в таблице Struct по совпадению login и name_Contract
    app.post('/view_struct', async (req, res) => {
      const { login, name_Contract } = req.body;

      const structRepository = connection.getRepository('Struct');
      console.log(login, name_Contract)
      // Ищем записи в таблице Struct, где login и name_Contract совпадают с введенными данными
      const matchingStructs = await structRepository.find({ where: { login, name_Contract } });

      // Возвращаем массив найденных структур
      return res.json({ struct: matchingStructs, });
    });
    // Добавляем функцию
    app.post('/add_function', async (req, res) => {
      const { name, login, name_Contract, text } = req.body;

      const functionRepository = connection.getRepository(Function);

      // Проверяем, существует ли запись с такими же значениями name, login и name_Contract
      const existingFunction = await functionRepository.findOne({
        where: {
          name: name,
          login: login,
          name_Contract: name_Contract,
        },
      });

      if (existingFunction) {
        // Если запись уже существует, отправляем сообщение об ошибке
        return res.status(400).json({ error: 'Function with the same values already exists' });
      }

      // Создаем новую сущность функции
      const newFunction = functionRepository.create();
      newFunction.name = name;
      newFunction.login = login;
      newFunction.name_Contract = name_Contract;
      newFunction.text = text;

      // Сохраняем новую функцию в базе данных
      try {
        await functionRepository.save(newFunction);
        res.status(201).json({ message: 'Function added successfully' });
      } catch (error) {
        console.error('Error adding function:', error.message);
        res.status(500).json({ error: 'Internal server error' });
      }
    });
    // просмотр функции
    app.get('/view_functions', async (req, res) => {
      const { login, name_Contract } = req.query; // Получаем значения login и name_Contract из запроса

      const functionRepository = connection.getRepository(Function);

      try {
        // Выполняем запрос к базе данных, чтобы получить записи с совпадающими login и name_Contract
        const functions = await functionRepository.find({
          where: {
            login: login,
            name_Contract: name_Contract,
          },
        });

        // Возвращаем найденные записи
        res.status(200).json({ functions: functions });
      } catch (error) {
        console.error('Error fetching functions:', error.message);
        res.status(500).json({ error: 'Internal server error' });
      }
    });
    // Добавьте этот маршрут после определения других маршрутов
    app.post('/remove_function', async (req, res) => {
      const { login, name_Contract, name } = req.body; // Получаем параметры для удаления

      const functionRepository = connection.getRepository('Function');

      try {
        // Находим функцию, которую нужно удалить
        const functionToRemove = await functionRepository.findOne({ where: { login, name_Contract, name } });

        if (!functionToRemove) {
          return res.status(400).json({ message: 'Функция не найдена' });
        }

        // Удаляем найденную функцию
        await functionRepository.remove(functionToRemove);

        return res.json({ message: 'Функция успешно удалена' });
      } catch (error) {
        console.error('Ошибка при удалении функции:', error);
        return res.status(500).json({ message: 'Произошла ошибка при удалении функции' });
      }
    });
    // Добавьте этот маршрут после определения других маршрутов
    app.post('/remove_struct', async (req, res) => {
      const { login, name_Contract, name } = req.body; // Получаем параметры для удаления

      const structRepository = connection.getRepository('Struct');

      try {
        // Находим структуру, которую нужно удалить
        const structToRemove = await structRepository.findOne({ where: { login, name_Contract, name } });

        if (!structToRemove) {
          return res.status(400).json({ message: 'Структура не найдена' });
        }

        // Удаляем найденную структуру
        await structRepository.remove(structToRemove);

        return res.json({ message: 'Структура успешно удалена' });
      } catch (error) {
        console.error('Ошибка при удалении структуры:', error);
        return res.status(500).json({ message: 'Произошла ошибка при удалении структуры' });
      }
    });
    //вывод инфы при входе
    app.post('/out', async (req, res) => {
      const userRepository = connection.getRepository('User'); // подключение к таблице 
      const { login } = req.body;
      const user = await userRepository.findOne({ where: { login } });
      return res.json({ color: user.color, });
    });
    //смена темы
    app.post('/update-theme', async (req, res) => {
      const { login, theme } = req.body;

      const userRepository = connection.getRepository('User');
      const user = await userRepository.findOne({ where: { login } });

      if (!user) {
        return res.status(400).json({ message: 'Пользователь не найден' });
      }

      user.color = theme; // Обновляем тему пользователя
      await userRepository.save(user);

      return res.json({ message: 'Тема обновлена успешно' });
    });
    // Добавление нового контракта
    app.post('/add_contract', async (req, res) => {
      const { login, name } = req.body; // Получаем имя контракта и логин пользователя из запроса

      const contractRepository = connection.getRepository('Contract');

      try {
        // Создание нового контракта
        const newContract = contractRepository.create();
        newContract.name = name;
        newContract.login = login;

        // Сначала сохраняем новый контракт
        await contractRepository.save(newContract);

        return res.json({ message: 'Контракт успешно добавлен' });
      } catch (error) {
        console.error('Ошибка при добавлении контракта:', error);
        return res.status(500).json({ message: 'Произошла ошибка при добавлении контракта' });
      }
    });
    // Возвращаем названия контрактов пользователя
    app.post('/user-contracts', async (req, res) => {
      const { login } = req.body;

      const userRepository = connection.getRepository('User');
      const contractRepository = connection.getRepository('Contract');

      try {
        const user = await userRepository.findOne({ where: { login } });

        if (!user) {
          return res.status(400).json({ message: 'Пользователь не найден' });
        }

        // Находим контракты, у которых совпадает логин пользователя и контракта
        const userContracts = await contractRepository.find({ where: { login } });

        const contractNames = userContracts.map(contract => contract.name);

        return res.json({ contractNames });
      } catch (error) {
        console.error('Ошибка при получении контрактов пользователя:', error);
        return res.status(500).json({ message: 'Произошла ошибка при получении контрактов пользователя' });
      }
    });
    // Удаление контракта
    app.post('/remove_contract', async (req, res) => {
      const { login, name } = req.body; // Получаем имя контракта и логин пользователя из запроса
      console.log(login, name);
      const contractRepository = connection.getRepository('Contract');

      try {
        // Находим контракт по имени и логину
        const contractToRemove = await contractRepository.findOne({ where: { login, name } });

        if (!contractToRemove) {
          return res.status(400).json({ message: 'Контракт не найден' });
        }

        // Удаляем найденный контракт
        await contractRepository.remove(contractToRemove);

        return res.json({ message: 'Контракт успешно удален' });
      } catch (error) {
        console.error('Ошибка при удалении контракта:', error);
        return res.status(500).json({ message: 'Произошла ошибка при удалении контракта' });
      }
    });
    //регистрация
    app.post('/register', async (req, res) => {
      const { login, password } = req.body;

      const userRepository = connection.getRepository('User');

      // Проверка наличия пользователя с таким логином
      const existingUser = await userRepository.findOne({ where: { login } });

      if (existingUser) {
        return res.status(400).json({ message: 'Такой пользователь уже существует' });
      }

      // Хеширование пароля
      bcrypt.hash(password, 10, async (err, hashedPassword) => {
        if (err) return res.status(500).json({ message: 'Error hashing password' });

        // Сохранение пользователя в базе данных
        const newUser = userRepository.create();
        console.log('BACK-5');
        newUser.login = login;
        newUser.password = hashedPassword;
        newUser.color = "write";

        await userRepository.save(newUser);

        return res.json({ message: 'Registration successful' });
      });
    });
    // Запуск сервера
    app.listen(port, () => {
      console.log(`Server is running on port ${port}`);
    });
  })
  .catch((error) => console.log('TypeORM connection error:', error));