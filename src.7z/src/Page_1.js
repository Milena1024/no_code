import React, { useState, useEffect } from "react";
//подключение gif, png
import pusk from './pictures/pusk.gif';
import axios from 'axios'; // запросы

function Page_1() {
  let [choice, ch] = useState("Вход");//переход между входом и регистрацией
  let [login, login_] = useState("");//логин
  let [password, password_] = useState("");//пароль
  let [password2, password2_] = useState("");//повторение пароля
  let [errors_, errors__] = useState(["false", "false"]);//ошибка, если пароли не совпадают
  let [error, error_] = useState(["false", "false", "false"]);//ошибка, если заполнена не вся информация
  sessionStorage.setItem("login", login);
  const [color, col] = useState("");
  sessionStorage.setItem("color", color);

  async function selection(a) {//функция переход между входом и регистрацией
    ch(a); login_(""); password_(""); password2_(""); errors__(["false", "false"]); error_(["false", "false", "false"]);
  }
  async function Authorization(a, b) {
    ch("Загрузка");

    if (a !== "" && b !== "") {
      error_(["false", "false"]);

      // Отправить запрос на сервер для аутентификации
      axios.post('http://localhost:3001/login', { login: a, password: b })
        .then(response => {
          console.log(response.data);

          axios.post('http://localhost:3001/out', { login: login })
            .then(response => {
              col(response.data.color);
            })
            .catch(error => {
              console.error(error);
            });

          document.location.href = "http://localhost:3000/Page_2";
        })
        .catch(error => {
          console.error(error);
          alert('Ошибка аутентификации: ' + error.response.data.message);
          ch("Вход");
        });
    } else {
      error_([login, password, "false"]);
      ch("Вход");
    }
  }

  async function Click_Authorization(e) {
    console.log(e.key)
    if (e.key === "Enter")
      Authorization();
  }

  async function Registration(a, b, c) {
    ch("Загрузка");

    if (a !== "" && b !== "" && c !== "") {
      console.log('stage_1')
      // errors_(["false", "false", "false"]);
      console.log('stage_2')

      if (b === c) {
        console.log('stage_3')

        errors__(["false", "false"]);

        console.log('stage_2')
        // Отправить запрос на сервер для регистрации
        axios.post('http://localhost:3001/register', { login: a, password: b })
          .then(response => {
            console.log(response.data);
            ch("Вход");
            login_("");
            password_("");
            password2_("");
          })
          .catch(error => {
            console.error(error);
            alert('Ошибка аутентификации: ' + error.response.data.message);
            ch("Регистрация");
          });
      } else {
        errors__(["true", errors_[1]]);
        ch("Регистрация");
      }
    } else {
      errors__(["false", errors_[1]]);
      ch("Регистрация");
      error_([a, b, c]);
    }
  }

  async function Click_Registration(e) {
    if (e.key === "Enter")
      Registration();
  }
  //ограничение на вводимые символы
  function onChangeTagInput(e) {
    login_(e.target.value.replace(/[^a-z._\-!?@0-9\s]/gi, ""));
    var regexp = /[a-z._\-!?@0-9\s]+$/i
    if (!e.target.value || regexp.test(e.target.value))
      errors__([errors_[0], "false"]);
    else
      errors__([errors_[0], "true"]);
  }

  return (
    <>
      <div className="write" >
        <br /><br /><br /><br /><br /><br /><br /><br />
        <center><h1 style={{ fontSize: 25, fontWeight: 'normal' }}>Авторизация</h1></center>{/*ЗАГОЛОВОК*/}

        <div style={{ display: "flex", alignItems: "center", justifyContent: "center" }}>
          <div className="block_write_two">
            <div style={{ float: "left", marginLeft: "20px" }}><br />{/*БЛОК В КОТОРОМ ПРОИСХОДИТ ВЕСЬ КИПИШ*/}

              {/*ОТВЕЧАЮТ ЗА ПЕРЕХОД МЕЖДУ ВХОД И РЕГИСТРАЦИЯ, БЛАГОДАРЯ УСЛОВИЮ ПОЯВЛЯЕТСЯ ФИОЛЕТОВАЯ ЛИНИЯ СВЕРХУ*/}
              {choice === "Вход" && <div ><button className="button_text" style={{ textDecoration: "underline", textDecorationColor: "#6d5bfd", textDecorationLine: "overline", textDecorationThickness: "2px" }} onClick={() => selection("Вход")}>Вход</button><button className="button_text" onClick={() => selection("Регистрация")}>Регистрация</button></div>}
              {choice === "Регистрация" && <div><button className="button_text" onClick={() => selection("Вход")}>Вход</button><button className="button_text" style={{ textDecoration: "underline", textDecorationColor: "#6d5bfd", textDecorationLine: "overline", textDecorationThickness: "2px" }} onClick={() => selection("Регистрация")}>Регистрация</button></div>}
              <h8 style={{ color: "#f2f2f3" }}>_____________________________________________________________</h8><br /><br /><br />

              {/*Вход*/}
              {choice === "Вход" && <div onKeyDown={Click_Authorization}>
                <input type="text" className="inputs" placeholder="Никнейм или email" value={login} onChange={(e) => login_(e.target.value)} />
                {error[0] === "" && <div style={{ color: "red", fontSize: "15px" }}>!</div>}
                {error[0] !== "" && <br />}{error[0] !== "" && <br />}
                <input type="password" name="password" class="inputs" placeholder="Пароль" value={password} onChange={(e) => password_(e.target.value)} />
                {error[1] === "" && <div style={{ color: "red", fontSize: "15px" }}>!</div>}
                {error[1] !== "" && <br />}{error[1] !== "" && <br />}
                <button className="button_write" onClick={() => Authorization(login, password)}>Войти</button><br /><br />
              </div>}

              {/*Регистрация*/}
              {choice === "Регистрация" && <div onKeyDown={Click_Registration}>
                <input type="text" className="inputs" placeholder={"Никнейм или email"} value={login} onChange={(e) => onChangeTagInput(e)} />
                {errors_[1] === "true" && <div style={{ color: "red", fontSize: "15px" }}>Может содержать только a-z, 0-9, ._\-!@?</div>}
                {error[0] === "" && errors_[1] !== "регистрация" && <div style={{ color: "red", fontSize: "15px" }}>!</div>}
                {error[0] !== "" && errors_[1] !== "true" && <br />}{error[0] !== "" && errors_[1] !== "true" && <br />}
                <input type="password" name="password" class="inputs" placeholder="Пароль" value={password} onChange={(e) => password_(e.target.value)} />
                {error[1] === "" && <div style={{ color: "red", fontSize: "15px" }}>!</div>}
                {error[1] !== "" && <br />}{error[1] !== "" && <br />}
                <input type="password" name="password" class="inputs" placeholder="Введите пароль повторно" value={password2} onChange={(e) => password2_(e.target.value)} /><br />
                {error[2] === "" && <div style={{ color: "red", fontSize: "15px" }}>!</div>}
                {errors_[0] === "true" && <div style={{ color: "red", fontSize: "15px" }}>Введенные пароли не совпадают!</div>}
                {error[2] !== "" && errors_[0] !== "true" && <div><br /></div>}
                <button className="button_write" onClick={() => Registration(login, password, password2)}>Зарегистрироваться</button><br /><br />
              </div>}

              {/*Гифка загрузка*/}
              {choice === "Загрузка" && <div><br /><br /><br /><center>
                <img src={pusk} width="150" alt="" /></center>
              </div>}
            </div></div></div></div>

    </>
  );
}

export default Page_1;
