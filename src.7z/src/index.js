import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import { GoogleOAuthProvider } from '@react-oauth/google';
ReactDOM.render(<GoogleOAuthProvider clientId="966037384439-9rst5olchjb47fiev2djlmri0upoceds.apps.googleusercontent.com">
    <React.StrictMode>
        <App />
    </React.StrictMode>
</GoogleOAuthProvider>, document.getElementById('root'));