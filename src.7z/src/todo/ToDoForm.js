import React, { useState } from "react";

function ToDoForm({ addTask }) {
    const [userinput, setUserInput] = useState('');
    const create = sessionStorage.getItem("create");
    let [error, error_] = useState("false");

    async function handleSubmit(e) {
        e.preventDefault()
        addTask(userinput); setUserInput("");
    }

    async function handleKeyPress(e) {
        if (e.key === "Enter")
            handleSubmit(e);
        error_("false");
    }
    //ограничение на вводимые символы
    function onChangeTagInput(e) {
        setUserInput(e.target.value.replace(/[^a-z_\s]/gi, ""));
        var regexp = /[a-z_\s]+$/i
        if ((!e.target.value || regexp.test(e.target.value)))
            error_("false");
        else
            error_("true");
    }

    return (<>
        {create === "o" && <form onSubmit={handleSubmit}>
            <input style={{ marginLeft: "9px" }} className="input" value={userinput} type="text" maxLength={15} onChange={(e) => onChangeTagInput(e)} onKeyDown={handleKeyPress} autoFocus={true} />
            {error === "true" && <div style={{ color: "red", fontSize: "15px", float: "left", marginLeft: "8px" }}>Может содержать только a-z, _</div>}
        </form>}
    </>
    )
}
export default ToDoForm;