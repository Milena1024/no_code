import React, { useState } from "react";
import ToDoFour from "../todo/ToDoFour";
//подключение подсказки при наведении на объекте
import { Tooltip } from 'react-tooltip'
//подключение svg
import arrow_down from '../pictures/arrow_down.svg';
import arrow_up from '../pictures/arrow_up.svg';
import arrow_down_black from '../pictures/arrow_down_black.svg';
import arrow_up_black from '../pictures/arrow_up_black.svg';

function ToDoThree({ todo }) {
    const color = sessionStorage.getItem("color");
    const [status, setstatus] = useState("c");
    const [todosfour, setTODOSFour] = useState([]);
    const [click, setclick] = useState("c");
    const [ret, setret] = useState("");


    async function addTaskFour() {//Функция добавления элемента в список

        let newItem = {
            id: Math.random().toString(36).substr(2, 9),
            complete: false
        };

        if (todo.task === "output") {
            newItem = {
                ...newItem, one: "", typeOne: "",
                two: "", typeTwo: "",
                three: "", typeThree: "",
                four: "", typeFour: "",
                five: "", typeFive: "",
                six: "", typeSix: "",
                seven: "", typeSeven: "",
            }
        } else if (todo.task === "output_text") {
            newItem = {
                ...newItem, one: "text", typeOne: "string",
                two: "", typeTwo: "",
                three: "", typeThree: "",
                four: "", typeFour: "",
                five: "", typeFive: "",
                six: "", typeSix: "",
                seven: "", typeSeven: "",
            };
        } else if (todo.task === "isGreaterThan10") {
            newItem = {
                ...newItem, one: "num", typeOne: "uint",
                two: "", typeTwo: "",
                three: "", typeThree: "",
                four: "", typeFour: "",
                five: "", typeFive: "",
                six: "", typeSix: "",
                seven: "", typeSeven: "",
            };
        } else if (todo.task === "compareStrings") {
            newItem = {
                ...newItem, one: "str1", typeOne: "string",
                two: "str2", typeTwo: "string",
                three: "", typeThree: "",
                four: "", typeFour: "",
                five: "", typeFive: "",
                six: "", typeSix: "",
                seven: "", typeSeven: "",
            };
        } else if (todo.task === "sum") {
            newItem = {
                ...newItem, one: "number", typeOne: "uint",
                two: "word", typeTwo: "string",
                three: "", typeThree: "",
                four: "", typeFour: "",
                five: "", typeFive: "",
                six: "", typeSix: "",
                seven: "", typeSeven: "",
            };
        } else if (todo.task === "addNumber") {
            newItem = {
                ...newItem, one: "number", typeOne: "uint",
                two: "word", typeTwo: "string",
                three: "", typeThree: "",
                four: "", typeFour: "",
                five: "", typeFive: "",
                six: "", typeSix: "",
                seven: "", typeSeven: "",
            };
        } else if (todo.task === "addNumber_two") {
            newItem = {
                ...newItem, one: "num", typeOne: "uint",
                two: "numbers", typeTwo: "uint",
                three: "", typeThree: "",
                four: "", typeFour: "",
                five: "", typeFive: "",
                six: "", typeSix: "",
                seven: "", typeSeven: "",
            };
        }


        await setTODOSFour(prevItems => [...prevItems, newItem]);
    }

    async function Start() {//Компиляция функции
        const variables = JSON.parse(localStorage.getItem("variables"));
        for (let i = 0; i < variables.length; i++) {
            console.log(variables);
        }
        if (todo.task === "output") {
            setret("string: Hello, world!");
        } else if (todo.task === "output_text") {
            setret("string: ");
            setret("string: " + variables[0]);
        } else if (todo.task === "isGreaterThan10") {
            setret("bool: ");
            if (variables[0] > 10)
                setret("bool: true");
            if (variables[0] <= 10 && variables[0] !== "")
                setret("bool: false");
        } else if (todo.task === "compareStrings") {
            if (variables[0] === variables[1])
                setret("bool: true");
            else
                setret("bool: false");

        } else if (todo.task === "sum") {
            let text = "";
            for (let i = 0; i < variables[0]; i++) {
                text += variables[1] + " ";
            }
            setret("string: " + text);

        } else if (todo.task === "addNumber") {
            let text = "";
            for (let i = 0; i < variables[0]; i++) {
                text += variables[1] + ", ";
            }
            setret("string[]: " + text);

        } else if (todo.task === "addNumber_two") {
            setret("uint: ");
            if (!isNaN(variables[0]) && !isNaN(variables[1]))
                setret("uint: " + variables[1]);
        }
        setclick("o");
    }

    return (<>
        <div key={todo.id}>
            <Tooltip id="my-tooltip" />

            {color === "write" && <div style={{ marginLeft: "9px" }}>
                <button style={{ maxWidth: "222px", minWidth: "222px" }} className="button_write" onClick={() => { Start() }}>{todo.task}</button>
                {status === "c" && <button style={{ float: "right", marginRight: "20px" }} className={"text"} onClick={() => { setstatus("o"); addTaskFour() }}><img src={arrow_down} width="25" alt="" /></button>}
                {status === "o" && <button style={{ float: "right", marginRight: "20px" }} className={"text"} onClick={() => { setstatus("c"); setTODOSFour([]); setclick("c") }}><img src={arrow_up} width="25" alt="" /></button>}
            </div>}
            {color === "black" && <div style={{ marginLeft: "9px" }}>
                <button style={{ maxWidth: "222px", minWidth: "222px" }} className="button_write" onClick={() => { Start() }}>{todo.task}</button>
                {status === "c" && <button style={{ float: "right", marginRight: "20px" }} className={"text"} onClick={() => { setstatus("o"); addTaskFour() }}><img src={arrow_down_black} width="25" alt="" /></button>}
                {status === "o" && <button style={{ float: "right", marginRight: "20px" }} className={"text"} onClick={() => { setstatus("c"); setTODOSFour([]); setclick("c") }}><img src={arrow_up_black} width="25" alt="" /></button>}
            </div>}
            {status === "o" && <div>
                {todosfour.map((todofour) => {
                    return (
                        <ToDoFour todofour={todofour} key={todofour.id} />
                    )
                })}<br />

            </div>}
            {status === "o" && <><br /><br /></>}
            <br /> {click === "o" && <div style={{ marginLeft: "9px" }}>{ret}<br /><br /></div>}
        </div>

    </>
    );
}
export default ToDoThree;