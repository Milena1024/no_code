import React, { useState } from "react";
//подключение подсказки при наведении на объекте
import 'react-tooltip/dist/react-tooltip.css';
import { Tooltip } from 'react-tooltip';
//подключение svg
import tick_square from '../pictures/tick_square.svg';
import tick_square_black from '../pictures/tick_square_black.svg';

function ToDoFormTwo({ check }) {
    const color = sessionStorage.getItem("color");
    const createtwo = sessionStorage.getItem("createtwo");
    const [userinput, setUserInput] = useState('');
    const [usertipe, setUseTipe] = useState('');
    let [error, error_] = useState("false");

    async function handleSubmitTwo(e) {
        e.preventDefault();
        check(userinput, usertipe);
        setUserInput("");
        setUseTipe("");
        error_("false");
    }

    if (createtwo === "c" && (userinput !== "" || usertipe !== "")) { //очистка полей ввода структуры
        setUserInput(""); setUseTipe(""); error_("false");
    }
    //ограничение на вводимые символы
    function onChangeTagInput(e) {
        setUserInput(e.target.value.replace(/[^a-z_\s]/gi, ""));
        var regexp = /[a-z_\s]+$/i
        if ((!e.target.value || regexp.test(e.target.value)))
            error_("false");
        else
            error_("true");
    }

    return (<>
        {createtwo === "o" && <form onSubmit={handleSubmitTwo} style={{ fontSize: "15px", display: "flex", alignItems: "center" }}>
            <Tooltip id="my-tooltiptwo" />
            <input className="inputsss" value={userinput} type="text" maxLength={10} onChange={(e) => onChangeTagInput(e)} placeholder="Название переменной" autoFocus={true} />&nbsp;
            <select className="button" value={usertipe} onChange={(e) => setUseTipe(e.currentTarget.value)}>
                <option value='' hidden>Тип переменной</option>
                <option value="string">string</option>
                <option value="uint">uint</option>
                <option value="bool">bool</option>
            </select>&nbsp;&nbsp;
            {color === "write" && userinput !== "" && usertipe !== "" && <button className="text" data-tooltip-id="my-tooltiptwo" data-tooltip-content="Добавить" onClick={(e) => { handleSubmitTwo(e) }}><img src={tick_square} width="25" alt="" /></button>}
            {color === "black" && userinput !== "" && usertipe !== "" && <button className="text" data-tooltip-id="my-tooltiptwo" data-tooltip-content="Добавить" onClick={(e) => { handleSubmitTwo(e) }}><img src={tick_square_black} width="25" alt="" /></button>}
        </form>}
        {error === "true" && <div style={{ color: "red", fontSize: "15px", float: "left", marginLeft: "8px" }}>Может содержать только a-z, _</div>}
        
    </>
    );
}
export default ToDoFormTwo;