import React, { useState } from "react";
//подключение подсказки при наведении на объекте
import { Tooltip } from 'react-tooltip'
//подключение svg
import trash_black from '../pictures/trash_black.svg';
import trash from '../pictures/trash.svg';

function ToDoFive({ todo, removeTaskFive }) {
    const color = sessionStorage.getItem("color");


    return (<>
        <div key={todo.id} style={{ fontSize: "15px", display: "flex" }}>
            <Tooltip id="my-tooltiptwo" />
            <input style={{ maxWidth: "350px", minWidth: "350px" }} className="inputsss" disabled value={todo.name} />
            &nbsp;&nbsp;
            {color === "write" && <button style={{ float: "right" }} className={"text"} data-tooltip-id="my-tooltiptwo" data-tooltip-content="Удалить" onClick={() => removeTaskFive(todo.id)}>
                <img src={trash} width="25" alt="" />
            </button>}
            {color === "black" && <button style={{ float: "right" }} className={"text"} data-tooltip-id="my-tooltiptwo" data-tooltip-content="Удалить" onClick={() => removeTaskFive(todo.id)}>
                <img src={trash_black} width="25" alt="" />
            </button>}
        </div>
    </>
    );
}
export default ToDoFive;