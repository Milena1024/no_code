import React, { useState, useEffect, useRef } from 'react';
//подключение подсказки при наведении на объекте
import { Tooltip } from 'react-tooltip'
//подключение svg
import document_code from '../pictures/document_code.svg';
import document_code_black from '../pictures/document_code_black.svg';
import document_code_active from '../pictures/document_code_active.svg';
//запросы
import axios from 'axios';

function ToDo({ todo, removeTask, tex }) {
    const color = sessionStorage.getItem("color");
    const text = sessionStorage.getItem("text");
    const structs = sessionStorage.getItem("structs");
    const fanctions = sessionStorage.getItem("fanctions");
    //пользователь
    const login = sessionStorage.getItem("login");

    //контекстное меню----
    const [showMenu, setShowMenu] = useState(false);
    const [menuPosition, setMenuPosition] = useState({ x: 0, y: 0 });
    const menuRef = useRef(null);

    function handleContextMenu(event) {
        event.preventDefault(); // отменяем стандартное контекстное меню браузера
        setShowMenu(true);
        setMenuPosition({ x: event.clientX, y: event.clientY });
    }

    function handleMenuClick(action) {
        switch (action) {
            case 'delete':
                const text = todo.task;
                axios.post('http://localhost:3001/remove_contract', { login: login, name: text })
                    .then(response => {
                        // Обработка успешного удаления контракта
                        console.log(response.data.message);
                        // Дополнительные действия при необходимости
                    })
                    .catch(error => {
                        // Обработка ошибки при удалении контракта
                        console.error(error);
                        // Дополнительные действия при необходимости
                    });
                removeTask(todo.id, todo.task);//удаление контракта

                break;
            case 'save'://скачивание файла
                const element = document.createElement("a");
                const file = new Blob(["// SPDX-License-Identifier: GPL-3.0\npragma solidity >=0.8.2 <0.9.0;\n\ncontract " + todo.task + " {\n\n" + structs + fanctions + "\n}"], { type: 'text/plain' });//ввод информации 
                element.href = URL.createObjectURL(file);
                element.download = todo.task; //название документа 
                document.body.appendChild(element);
                element.click();
                break;
            default:
                break;
        }
        setShowMenu(false);
    }

    useEffect(() => {
        // добавляем обработчик событий клика к объекту document
        document.addEventListener('click', handleClick);
        return () => {
            // удаляем обработчик событий при размонтировании компонента
            document.removeEventListener('click', handleClick);
        };
    }, [showMenu]); // обновляем только при изменении значения showMenu

    function handleClick(event) {
        // если клик был сделан вне контекстного меню, закрываем его
        if (menuRef.current && !menuRef.current.contains(event.target)) {
            setShowMenu(false);
        }
    }
    //----

    return (
        <div key={todo.id} onClick={handleClick}>
            <Tooltip id="my-tooltip" />
            {color === "write" && <div>
                <button onContextMenu={handleContextMenu} style={{ cursor: 'context-menu', color: text === todo.task ? '#6d5bfd' : '' }} data-tooltip-id="my-tooltip" data-tooltip-content="Открыть контракт" className={"text_" + color} onClick={() => tex(todo.task)}><img src={text === todo.task ? document_code_active : document_code} width="25" alt="" />&nbsp;&nbsp;{todo.task}.sol</button>
                {showMenu && (
                    <div ref={menuRef} style={{ position: 'absolute', left: menuPosition.x, top: menuPosition.y }} className="context-menu">
                        <ul>
                            <li onClick={() => handleMenuClick('delete')}>Удалить</li>
                            <li onClick={() => handleMenuClick('save')}>Cкачать</li>
                        </ul>
                    </div>
                )}
            </div>}

            {color === "black" && <div>
                <button onContextMenu={handleContextMenu} style={{ cursor: 'context-menu', color: text === todo.task ? '#6d5bfd' : '' }} data-tooltip-id="my-tooltip" data-tooltip-content="Открыть контракт" className={"text_" + color} onClick={() => tex(todo.task)}><img src={text === todo.task ? document_code_active : document_code_black} width="25" alt="" />&nbsp;&nbsp;{todo.task}.sol</button>
                {showMenu && (
                    <div ref={menuRef} style={{ position: 'absolute', left: menuPosition.x, top: menuPosition.y }} className="context-menu">
                        <ul>
                            <li onClick={() => handleMenuClick('delete')}>Удалить</li>
                            <li onClick={() => handleMenuClick('save')}>Скачать</li>
                        </ul>
                    </div>
                )}
            </div>}
        </div>
    )
}
export default ToDo;