import React, { useState } from "react";
//подключение подсказки при наведении на объекте
import { Tooltip } from 'react-tooltip'
//подключение svg

function ToDoFour({ todofour }) {
    const [variables, setVariables] = useState(["", "", "", "", "", "", ""]);
    localStorage.setItem("variables", JSON.stringify(variables));

    const handleVariableChange = (e, index) => {//записываем введённые данные в массив
        setVariables([...variables.slice(0, index), e.target.value, ...variables.slice(index + 1)])
    }

    return (<>
        <div key={todofour.id} style={{ fontSize: "15px" }}>
            <Tooltip id="my-tooltip" />
            {todofour.one !== "" && <div style={{ float: "right", marginRight: "9px" }}><input className="inputsss_block" disabled value={todofour.one} /> <input className="inputsss" placeholder={todofour.typeOne} onChange={(e) => handleVariableChange(e, 0)} /><br /></div>}
            {todofour.two !== "" && <div style={{ float: "right", marginRight: "9px" }}><input className="inputsss_block" disabled value={todofour.two} /> <input className="inputsss" placeholder={todofour.typeTwo} onChange={(e) => handleVariableChange(e, 1)} /><br /></div>}
            {todofour.three !== "" && <div style={{ float: "right", marginRight: "9px" }}><input className="inputsss_block" disabled value={todofour.three} />  <input className="inputsss" placeholder={todofour.typeThree} onChange={(e) => handleVariableChange(e, 2)} /><br /></div>}
            {todofour.four !== "" && <div style={{ float: "right", marginRight: "9px" }}><input className="inputsss_block" disabled value={todofour.four} />  <input className="inputsss" placeholder={todofour.typeFour} onChange={(e) => handleVariableChange(e, 3)} /><br /></div>}
            {todofour.five !== "" && <div style={{ float: "right", marginRight: "9px" }}><input className="inputsss_block" disabled value={todofour.five} />  <input className="inputsss" placeholder={todofour.typeFive} onChange={(e) => handleVariableChange(e, 4)} /><br /></div>}
            {todofour.six !== "" && <div style={{ float: "right", marginRight: "9px" }}><input className="inputsss_block" disabled value={todofour.six} />  <input className="inputsss" placeholder={todofour.typeSix} onChange={(e) => handleVariableChange(e, 5)} /><br /></div>}
            {todofour.seven !== "" && <div style={{ float: "right", marginRight: "9px" }}><input className="inputsss_block" disabled value={todofour.seven} />  <input className="inputsss" placeholder={todofour.typeSeven} onChange={(e) => handleVariableChange(e, 6)} /><br /></div>}
        </div>
    </>
    );
}
export default ToDoFour;