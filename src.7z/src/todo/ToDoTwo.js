//подключение подсказки при наведении на объекте
import { Tooltip } from 'react-tooltip'
//подключение svg
import close_square from '../pictures/close_square.svg';
import close_square_black from '../pictures/close_square_black.svg';

function ToDoTwo({ todo, removeTaskTwo }) {
    const color = sessionStorage.getItem("color");

    return (<>
        <div key={todo.id} style={{ fontSize: "15px", display: "flex", alignItems: "center" }}>
            <Tooltip id="my-tooltiptwo" />
            <input className="inputsss" disabled value={todo.task} /> &nbsp;
            <input className="inputsss" disabled value={todo.tip} /> &nbsp;&nbsp;
            {color === "write" && <button style={{ float: "right" }} className={"text"} data-tooltip-id="my-tooltiptwo" data-tooltip-content="Удалить переменную" onClick={() => removeTaskTwo(todo.id)}>
                <img src={close_square} width="25" alt="" />
            </button>}
            {color === "black" && <button style={{ float: "right" }} className={"text"} data-tooltip-id="my-tooltiptwo" data-tooltip-content="Удалить переменную" onClick={() => removeTaskTwo(todo.id)}>
                <img src={close_square_black} width="25" alt="" />
            </button>}
        </div>
    </>
    );
}
export default ToDoTwo;