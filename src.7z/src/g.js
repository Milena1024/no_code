import React, { useState } from "react";
import { ScrollSync, ScrollSyncPane } from 'react-scroll-sync';
//подключение роутинга
import { Link } from 'react-router-dom';
//подключение копирования
import { CopyToClipboard } from 'react-copy-to-clipboard';
//подключение подсказки при наведении на объекте
import 'react-tooltip/dist/react-tooltip.css';
import { Tooltip } from 'react-tooltip';
//подключение списка
import ToDo from "./todo/ToDo";
import ToDoForm from "./todo/ToDoForm";
import ToDoTwo from "./todo/ToDoTwo";
import ToDoFormTwo from "./todo/ToDoFormTwo";
import ToDoThree from "./todo/ToDoThree";
//подключение модального окна
import Modal from "./modal_window/Modal";
//подключение svg, png, gif
import user from './pictures/user.svg';
import moon from './pictures/moon.svg';
import copy from './pictures/copy.svg';
import code from './pictures/code.svg';
import code_black from './pictures/code_black.svg';
import code_active from './pictures/code_active.svg';
import box from './pictures/box.svg';
import box_black from './pictures/box_black.svg';
import box_active from './pictures/box_active.svg';
import copy_black from './pictures/copy_black.svg';
import document from './pictures/document.svg';
import document_black from './pictures/document_black.svg';
import document_active from './pictures/document_active.svg';
import add_square from './pictures/add_square.svg';
import add_square_black from './pictures/add_square_black.svg';
import lamp_on from './pictures/lamp_on.svg';
import lamp_on_black from './pictures/lamp_on_black.svg';
import eraser from './pictures/eraser.svg';
import eraser_black from './pictures/eraser_black.svg';
import book from './pictures/book.svg';
import book_black from './pictures/book_black.svg';
import book_active from './pictures/book_active.svg';
import play from './pictures/play.svg';
import play_black from './pictures/play_black.svg';
import play_active from './pictures/play_active.svg';
import code_two from './pictures/code_two.svg';
import code_two_black from './pictures/code_two_black.svg';
import code_two_active from './pictures/code_two_active.svg';
import documentwrite from './pictures/documentwrite.svg';
import documentblack from './pictures/documentblack.svg';
import documentactive from './pictures/documentactive.svg';
import logo from './pictures/logo.png';
import trash_black from './pictures/trash_black.svg';
import trash from './pictures/trash.svg';
import sun from './pictures/sun.svg';

function Page_2() {
  const [color, col] = useState("write");//тема
  sessionStorage.setItem("color", color);
  //CONTRACT
  const [text, t] = useState("");//название контракта
  sessionStorage.setItem("text", text);
  const [contract, c] = useState("");//код контракта
  const [create, create_] = useState("c");//открывает / закрывает создание контракта
  sessionStorage.setItem("create", create);
  const [todos, setTODOS] = useState([]);//просмотр контрактов
  const [compilation, com] = useState("");//просмотр компиляции
  //MODAL WINDOW
  const [modal_click, modal_click_] = useState("");//выбор содержимого модального окна
  const [modalActive, setModalActive] = useState(false);//подключение модального окна
  //STRUCT
  const [todostwo, setTODOStwo] = useState([]);//просмотр переменных структуры
  sessionStorage.setItem("todostwo", todostwo);
  const [createtwo, createtwo_] = useState("c");//открывает / закрывает создание переменной
  sessionStorage.setItem("createtwo", createtwo);
  const [struct, STRUCT] = useState("");//нзвание структуры
  const [structs, s] = useState("");//структуры кода
  const [error_struct, error_struct_] = useState("false");//ошибка, если название элементов совпадает
  const [connection, connection_] = useState("");//тип связи для mapping
  const [error, error_] = useState("false");
  const [radios, radios_] = useState("");// array || mapping
  //МЕНЮ
  const [menu, menu_] = useState("Контракты");
  //Рукописный код
  const [codes, setCodes] = useState("");
  //справка
  const [help, setHelp] = useState("");
  const [activeIndex, setActiveIndex] = useState(null);
  //добавление функций
  const [todosthree, setTODOSThree] = useState([]);
  const [start, setstart] = useState("c")

  async function click(e) {//функция открыть / закрыть контракт
    if (e === "Создать контракт") {
      if (create === "c")
        create_("o");
      else
        create_("c");
    }
    if (e === "Добавить переменную") {
      if (createtwo === "c")
        createtwo_("o");
      else
        createtwo_("c");
    }
  }
  async function COLORS() {//функция смена темы
    if (color === "write")
      col("black");
    else
      col("write");
  }
  async function addTask(userinput) {//Функция добавления элемента в список
    if (userinput) {
      const newItem = {
        id: Math.random().toString(36).substr(2, 9),
        task: userinput,
        complete: false
      }
      setTODOS([...todos, newItem]); create_("c");
    }
  }
  async function removeTask(id, e) {//функция удаления элемента списка
    setTODOS([...todos.filter((todo) => todo.id !== id)]);
    if (e === text) { // если удаляем контракт, а его код открыт, то он обнуляется
      t(""); c(""); s(""); STRUCT("");
    }
  }
  async function tex(e) {//функция заполнения кода контракта
    if (e !== text) {
      t(e); c("// SPDX-License-Identifier: GPL-3.0\npragma solidity >=0.8.2 <0.9.0;\n\ncontract " + e.charAt(0).toUpperCase() + e.slice(1) + " {\n\n");
    }
    else {
      t(""); c(""); //s("");
    }
  }
  //struct
  async function addTaskTwo(userinput, usertipe) {//Функция добавления элемента в список
    if (userinput && usertipe) {
      const newItem = {
        id: todostwo.length,
        task: userinput,
        tip: usertipe,
        complete: false
      }
      setTODOStwo([...todostwo, newItem]); createtwo_("c"); error_struct_("false"); error_("false");
    }
  }
  async function removeTaskTwo(id) {//функция удаления элемента списка
    setTODOStwo([...todostwo.filter((todo) => todo.id !== id)])
  }
  async function save() {
    //просмотр данных структуры
    let str = structs + "struct " + struct + " {\n";
    todostwo.map((e) => {
      str += " " + e.tip + " " + e.task + ";\n";
    })
    if (radios === "array")
      str += "}\n" + struct + "[] " + struct + "_;\n\n";
    if (radios === "mapping")
      str += "}\nmapping (" + connection + " => " + struct + ") " + struct + "_;\n\n";
    s(str);
    error_struct_("false"); createtwo_("c"); setTODOStwo([]); error_("false"); connection_(""); radios_("");
  }
  //проверка на повтрение названий элементов структуры
  async function check(userinput, usertipe) {
    let str = "false";
    todostwo.map((e) => {
      if (e.task === userinput) {
        str = "true";
        error_struct_("true");
      }
    })
    if (str === "false") {
      addTaskTwo(userinput, usertipe); error_struct_("false");
    }
  }
  //очистка поля
  async function Eraser(e) {
    if (e === "Добавить структуру") {
      STRUCT(""); error_struct_("false"); createtwo_("c"); setTODOStwo([]); error_("false"); connection_(""); radios_("");
    }
  }
  //ограничение на вводимые символы
  function onChangeTagInput(e) {
    STRUCT(e.target.value.replace(/[^a-z_\s]/gi, ""));
    var regexp = /[a-z_\s]+$/i
    if ((!e.target.value || regexp.test(e.target.value)))
      error_("false");
    else
      error_("true");
  }
  //Справка
  const handleClick = (index) => {
    setActiveIndex(index);
  }
  //Добавление функций
  async function addTaskThree() {//Функция добавления элемента в список
    for (let i = 1; i <= 5; i++) {
      const newItem = {
        id: Math.random().toString(36).substr(2, 9),
        task: text,
        complete: false
      }
      await setTODOSThree(prevItems => [...prevItems, newItem]);
    }
    setstart("o");
  }

  const [activeIndex2, setActiveIndex2] = useState(0);
  const handleButtonClick2 = (index) => {
    setActiveIndex2(index);
  };

  

  return (
    <>
      <div className={color} style={{ backgroundImage: `url(${logo})`, backgroundSize: "auto", backgroundRepeat: "no-repeat", backgroundPosition: "center" }}>
        <Tooltip id="my-tooltip" />{/*подсказки при наведении на объекте дописывается data-tooltip-id="my-tooltip" data-tooltip-content="Комментарий*/}

        <header className="navbar">
          <button style={{ float: "right", marginRight: "20px" }} className="text" data-tooltip-id="my-tooltip" data-tooltip-content="Сменить тему" onClick={() => COLORS()}><img src={color === "write" ? moon : sun} width="28" alt="" /></button>
          <Link to="/Page_1"><button className="text" style={{ marginRight: "20px" }} data-tooltip-id="my-tooltip" data-tooltip-content="Выйти из личного кабинета"><img src={user} width="25" alt="" /></button></Link>&nbsp;
        </header>

        <div style={{ display: "flex" }}>
          {/*пред-левый блок*/}
          {color === "write" && <div className={"block_" + color + "_2"} style={{ float: "right" }}>
            <div style={{ float: "left", marginLeft: "5px" }}><br />
              <button className="text" data-tooltip-id="my-tooltip" data-tooltip-content="Справка" onClick={() => { setModalActive(true); modal_click_("Главная_Справка"); setHelp(""); handleClick(null) }}><img src={modal_click === "Главная_Справка" && modalActive === true ? book_active : book} /></button><br /><br /><br />
              <button className="text" data-tooltip-id="my-tooltip" data-tooltip-content="Контракты" onClick={() => { menu_("Контракты"); setTODOSThree([]); setstart("c"); handleButtonClick2(0); }}><img src={activeIndex2 === 0 ? document_active : document_black} width="25" alt="" /></button><br /><br />
              {text !== "" && <><button className="text" data-tooltip-id="my-tooltip" data-tooltip-content="Компиляция" onClick={() => { menu_("Компиляция"); handleButtonClick2(1); }}><img src={activeIndex2 === 1 ? play_active : play} width="25" alt="" /></button><br /><br /></>}
              <button className="text" data-tooltip-id="my-tooltip" data-tooltip-content="Рукописный код" onClick={() => { menu_("Рукописный код"); t(""); handleButtonClick2(2); }}><img src={activeIndex2 === 2 ? code_two_active : code_two} width="25" alt="" /></button><br /><br />
            </div>
          </div>}
          {color === "black" && <div className={"block_" + color + "_2"} style={{ float: "right" }}>
            <div style={{ float: "left", marginLeft: "5px" }}><br />
              <button className="text" data-tooltip-id="my-tooltip" data-tooltip-content="Справка" onClick={() => { setModalActive(true); modal_click_("Главная_Справка"); setHelp(""); handleClick(null) }}><img src={modal_click === "Главная_Справка" && modalActive === true ? book_active : book_black} width="25" alt="" /></button><br /><br /><br />
              <button className="text" data-tooltip-id="my-tooltip" data-tooltip-content="Контракты" onClick={() => { menu_("Контракты"); setTODOSThree([]); setstart("c"); handleButtonClick2(0); }}><img src={activeIndex2 === 0 ? document_active : document} width="25" alt="" /></button><br /><br />
              {text !== "" && <><button className="text" data-tooltip-id="my-tooltip" data-tooltip-content="Компиляция" onClick={() => { menu_("Компиляция"); handleButtonClick2(1); }}><img src={activeIndex2 === 1 ? play_active : play_black} width="25" alt="" /></button><br /><br /></>}
              <button className="text" data-tooltip-id="my-tooltip" data-tooltip-content="Рукописный код" onClick={() => { menu_("Рукописный код"); t(""); handleButtonClick2(2); }}><img src={activeIndex2 === 2 ? code_two_active : code_two_black} width="25" alt="" /></button><br /><br />
            </div>
          </div>}

          {/*левый блок*/}
          {/*Контракты*/}
          {color === "write" && menu === "Контракты" && <div className={"block_" + color} style={{ float: "left" }}><br />
            <div style={{ float: "right", marginRight: "20px" }}>
              <button className="text" data-tooltip-id="my-tooltip" data-tooltip-content="Создать контракт" onClick={() => click("Создать контракт")}><img src={create === "o" ? documentactive : documentwrite} width="25" alt="" /></button>
            </div><br /><br />
            {/*Список контрактов*/}
            <div >
              {todos.map((todo) => {
                return (<ToDo todo={todo} key={todo.id} removeTask={removeTask} tex={tex} />
                )
              })}
              <ToDoForm addTask={addTask} />
            </div>
          </div>}
          {color === "black" && menu === "Контракты" && <div className={"block_" + color} style={{ float: "left" }}><br />
            <div text={text} style={{ float: "right", marginRight: "20px" }}>
              <button className="text" data-tooltip-id="my-tooltip" data-tooltip-content="Создать контракт" onClick={() => click("Создать контракт")}><img src={create === "o" ? documentactive : documentblack} width="25" alt="" /></button>
            </div><br /><br />
            {/*Список контрактов */}
            <div >
              {todos.map((todo) => {
                return (
                  <ToDo todo={todo} key={todo.id} removeTask={removeTask} tex={tex} />
                )
              })}
              <ToDoForm addTask={addTask} />
            </div>
          </div>}
          {/*Компиляция*/}
          {color === "write" && menu === "Компиляция" && <div className={"block_" + color}>
            {start === "c" && <button className="button_write" onClick={addTaskThree}>
              Компилировать
            </button>}
            {start === "o" && <><br /></>}
            {start === "o" && <button style={{ float: "right", marginRight: "20px" }} className="text" data-tooltip-id="my-tooltip" data-tooltip-content="Удалить компиляцию" onClick={() => { setstart("c"); setTODOSThree([]); }}><img src={trash} width="25" alt="" /></button>}
            <br /><br />
            {todosthree.map((todo) => {
              {/*Импуты */ }
              return (
                <ToDoThree todo={todo} key={todo.id} />
              )
            })}
          </div>}
          {color === "black" && menu === "Компиляция" && <div className={"block_" + color}>
            {start === "c" && <button className="button_write" onClick={addTaskThree}>
              Компилировать
            </button>}
            {start === "o" && <><br /></>}
            {start === "o" && <button style={{ float: "right", marginRight: "20px" }} className="text" data-tooltip-id="my-tooltip" data-tooltip-content="Удалить компиляцию" onClick={() => { setstart("c"); setTODOSThree([]); }}><img src={trash_black} width="25" alt="" /></button>}
            <br /><br />
            {todosthree.map((todo) => {
              {/*Импуты */ }
              return (
                <ToDoThree todo={todo} key={todo.id} />
              )
            })}
          </div>}
          {/*Рукописный код*/}
          {color === "write" && menu === "Рукописный код" && <div className={"block_" + color} style={{ float: "left" }}><br />
            Рукописный код
          </div>}
          {color === "black" && menu === "Рукописный код" && <div className={"block_" + color} style={{ float: "left" }}><br />
            Рукописный код
          </div>}

          {/*область для кода*/}
          {text !== "" && <div className="textarea-container">
            <ScrollSync>
              <div className="code-editor" style={{ resize: "vertical", overflow: "hidden", cursor: 'ns-resize', maxHeight: "70vh" }}>
                <ScrollSyncPane>
                  <div className={"line-numbers_" + color} style={{ height: "66.5vh", maxheight: "75.5vh" }}>
                    {(contract + structs + "\n}").split('\n').map((_, i) => (
                      <div key={i}>{i + 1}</div>
                    ))}
                  </div>
                </ScrollSyncPane>
                <ScrollSyncPane>
                  <textarea
                    className={"textarea_" + color}
                    style={{ width: "148vh", height: "66.3vh", maxheight: "75.5vh" }}
                    type="text"
                    disabled
                    autoFocus={true}
                    value={contract + structs + "\n}"}
                    onChange={(e) => c(e.target.value)}
                  />
                </ScrollSyncPane>
              </div>
            </ScrollSync>
            <textarea className={"textarea_" + color} style={{ width: "155vh", borderTop: '2px solid #c0c0c040' }} type="text" value={compilation} onChange={(e) => com(e.currentTarget.value)} />

          </div>}
          {/*Рукописный код*/}
          {menu === "Рукописный код" && text === "" && <div className="textarea-container">
            {/*нумирация строк*/}
            <ScrollSync>
              <div className="code-editor" style={{ resize: "vertical", overflow: "hidden", cursor: 'ns-resize', maxHeight: "70vh" }}>
                <ScrollSyncPane>
                  <div className={"line-numbers_" + color} style={{ height: "66.5vh", maxheight: "75.5vh" }}>
                    {codes.split('\n').map((_, i) => (
                      <div key={i}>{i + 1}</div>
                    ))}
                  </div>
                </ScrollSyncPane>
                <ScrollSyncPane>
                  <textarea
                    className={"textarea_" + color}
                    style={{ width: "148vh", height: "66.3vh", maxheight: "75.5vh" }}
                    type="text"
                    value={codes}
                    autoFocus={true}
                    onChange={(e) => setCodes(e.target.value)}
                  />
                </ScrollSyncPane>
              </div>
            </ScrollSync>
            <textarea className={"textarea_" + color} style={{ width: "155vh", borderTop: '2px solid #c0c0c040' }} type="text" value={compilation} onChange={(e) => com(e.currentTarget.value)} />
          </div>}

          {/*правый блок*/}
          {color === "write" && text !== "" && <div className={"block_" + color + "_2"} style={{ float: "right" }}>
            {menu !== "Компиляция" && <div style={{ float: "left", marginLeft: "5px" }}><br />
              {menu === "Контракты" && <><button className="text" data-tooltip-id="my-tooltip" data-tooltip-content="Добавить структуру" onClick={() => { setModalActive(true); modal_click_("Добавить структуру"); setHelp(""); }}><img src={modal_click === "Добавить структуру" && modalActive === true ? box_active : box} width="25" alt="" /></button><br /><br /></>}
              {menu === "Контракты" && <><button className="text" data-tooltip-id="my-tooltip" data-tooltip-content="Добавить функцию" onClick={() => { setModalActive(true); modal_click_("Добавить функцию") }}><img src={modal_click === "Добавить функцию" && modalActive === true ? code_active : code} width="25" alt="" /></button><br /><br /></>}
              <button className="text" data-tooltip-id="my-tooltip" data-tooltip-content="Справка" onClick={() => { setModalActive(true); modal_click_("Справка"); setHelp(""); handleClick(null) }}><img src={modal_click === "Справка" && modalActive === true ? book_active : book} width="25" alt="" /></button><br /><br /><br />
              <CopyToClipboard text={contract + structs + "\n}"}><button className="text" data-tooltip-id="my-tooltip" data-tooltip-content="Копировать код"><img src={copy_black} width="25" alt="" /></button></CopyToClipboard><br /><br />
              <br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br />
              {compilation !== "" && <button className="text" data-tooltip-id="my-tooltip" data-tooltip-content="Очистить" onClick={() => { com("") }}><img src={eraser} width="25" alt="" /></button>}
            </div>}
            {menu === "Компиляция" && <div style={{ float: "left", marginLeft: "5px" }}>
              <br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br />
              {compilation !== "" && <button className="text" data-tooltip-id="my-tooltip" data-tooltip-content="Очистить" onClick={() => { com("") }}><img src={eraser} width="25" alt="" /></button>}</div>}
          </div>}
          {color === "black" && text !== "" && <div className={"block_" + color + "_2"} style={{ float: "right" }}>
            {menu !== "Компиляция" && <div style={{ float: "left", marginLeft: "5px" }}><br />
              {menu === "Контракты" && <><button className="text" data-tooltip-id="my-tooltip" data-tooltip-content="Добавить структуру" onClick={() => { setModalActive(true); modal_click_("Добавить структуру"); setHelp(""); }}><img src={modal_click === "Добавить структуру" && modalActive === true ? box_active : box_black} width="25" alt="" /></button><br /><br /></>}
              {menu === "Контракты" && <><button className="text" data-tooltip-id="my-tooltip" data-tooltip-content="Добавить функцию" onClick={() => { setModalActive(true); modal_click_("Добавить функцию") }}><img src={modal_click === "Добавить функцию" && modalActive === true ? code_active : code_black} width="25" alt="" /></button><br /><br /></>}
              <button className="text" data-tooltip-id="my-tooltip" data-tooltip-content="Справка" onClick={() => { setModalActive(true); modal_click_("Справка"); setHelp(""); handleClick(null) }}><img src={modal_click === "Справка" && modalActive === true ? book_active : book_black} width="25" alt="" /></button><br /><br /><br />
              <CopyToClipboard text={contract + structs + "\n}"}><button className="text" data-tooltip-id="my-tooltip" data-tooltip-content="Копировать код"><img src={copy} width="25" alt="" /></button></CopyToClipboard><br /><br />
              <br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br />
              {compilation !== "" && <button className="text" data-tooltip-id="my-tooltip" data-tooltip-content="Очистить" onClick={() => { com("") }}><img src={eraser_black} width="25" alt="" /></button>}
            </div>}
            {menu === "Компиляция" && <div style={{ float: "left", marginLeft: "5px" }}>
              <br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br />
              {compilation !== "" && <button className="text" data-tooltip-id="my-tooltip" data-tooltip-content="Очистить" onClick={() => { com("") }}><img src={eraser_black} width="25" alt="" /></button>}</div>}
          </div>}
          {/*Рукописный код*/}
          {color === "write" && menu === "Рукописный код" && <div className={"block_" + color + "_2"} style={{ float: "right" }}>
            <div style={{ float: "left", marginLeft: "5px" }}><br />
              <button className="text" data-tooltip-id="my-tooltip" data-tooltip-content="Справка" onClick={() => { setModalActive(true); modal_click_("Справка") }}><img src={modal_click === "Справка" && modalActive === true ? book_active : book} width="25" alt="" /></button><br /><br />
              <CopyToClipboard text={codes}><button className="text" data-tooltip-id="my-tooltip" data-tooltip-content="Копировать код"><img src={copy_black} width="25" alt="" /></button></CopyToClipboard><br /><br />
              <button className="text" data-tooltip-id="my-tooltip" data-tooltip-content="Очистить" onClick={() => { setCodes("") }}><img src={eraser} width="25" alt="" /></button><br /><br />
              <br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br />
              {compilation !== "" && <button className="text" data-tooltip-id="my-tooltip" data-tooltip-content="Очистить" onClick={() => { com("") }}><img src={eraser} width="25" alt="" /></button>}
            </div></div>}
          {color === "black" && menu === "Рукописный код" && <div className={"block_" + color + "_2"} style={{ float: "right" }}>
            <div style={{ float: "left", marginLeft: "5px" }}><br />
              <button className="text" data-tooltip-id="my-tooltip" data-tooltip-content="Справка" onClick={() => { setModalActive(true); modal_click_("Справка") }}><img src={modal_click === "Справка" && modalActive === true ? book_active : book_black} width="25" alt="" /></button><br /><br />
              <CopyToClipboard text={codes}><button className="text" data-tooltip-id="my-tooltip" data-tooltip-content="Копировать код"><img src={copy} width="25" alt="" /></button></CopyToClipboard><br /><br />
              <button className="text" data-tooltip-id="my-tooltip" data-tooltip-content="Очистить" onClick={() => { setCodes("") }}><img src={eraser_black} width="25" alt="" /></button><br /><br />
              <br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br />
              {compilation !== "" && <button className="text" data-tooltip-id="my-tooltip" data-tooltip-content="Очистить" onClick={() => { com("") }}><img src={eraser_black} width="25" alt="" /></button>}
            </div></div>}
        </div>

        {/*модальное окно*/}
        <Modal active={modalActive} setActive={setModalActive} style={{ padding: "0 20px", paddingTop: "20px", paddingBottom: "20px" }}>
          <Tooltip id="my-tooltiptwo" />

          {modal_click === "Добавить структуру" && <div>
            {color === "write" && <button style={{ float: "right" }} className="text" data-tooltip-id="my-tooltiptwo" data-tooltip-content="Справка" onClick={() => { setHelp(help === "Структура" ? '' : 'Структура') }}><img src={help === "Структура" ? book_active : book} /></button>}
            {color === "black" && <button style={{ float: "right" }} className="text" data-tooltip-id="my-tooltiptwo" data-tooltip-content="Справка" onClick={() => { setHelp(help === "Структура" ? '' : 'Структура') }}><img src={help === "Структура" ? book_active : book_black} width="25" alt="" /></button>}
            {color === "write" && struct !== "" && <button style={{ float: "right" }} className="text" data-tooltip-id="my-tooltiptwo" data-tooltip-content="Очистить" onClick={() => Eraser("Добавить структуру")}><img src={eraser} width="25" alt="" /></button>}
            {color === "black" && struct !== "" && <button style={{ float: "right" }} className="text" data-tooltip-id="my-tooltiptwo" data-tooltip-content="Очистить" onClick={() => Eraser("Добавить структуру")}><img src={eraser_black} width="25" alt="" /></button>}
            {error === "true" && <div style={{ color: "red", fontSize: "15px" }}>Может содержать только a-z, _</div>}<br />{error === "false" && <br />}
            <div style={{ display: "flex", alignItems: "center" }}><br />
              <input className="inputss" type="text" autoFocus={true} placeholder="Название структуры" value={struct} onChange={(e) => onChangeTagInput(e)} />&nbsp;&nbsp;
              {struct !== "" && <div>
                {color === "write" && todostwo.length < 7 && <button className="text" data-tooltip-id="my-tooltiptwo" data-tooltip-content="Добавить переменную" onClick={() => { click("Добавить переменную"); error_struct_("false"); error_("false") }}><img src={add_square} width="25" alt="" /></button>}
                {color === "black" && todostwo.length < 7 && <button className="text" data-tooltip-id="my-tooltiptwo" data-tooltip-content="Добавить переменную" onClick={() => { click("Добавить переменную"); error_struct_("false"); error_("false") }}><img src={add_square_black} width="25" alt="" /></button>}
                {color === "write" && todostwo.length === 7 && <button style={{ float: "right" }} className={"text"} data-tooltip-id="my-tooltiptwo" data-tooltip-content="Структура может содержать не более 7 элементов!" ><img src={lamp_on} width="25" alt="" /></button>}
                {color === "black" && todostwo.length === 7 && <button style={{ float: "right" }} className={"text"} data-tooltip-id="my-tooltiptwo" data-tooltip-content="Структура может содержать не более 7 элементов!" ><img src={lamp_on_black} width="25" alt="" /></button>}
              </div>}
            </div>

            {error_struct === "false" && <br />}
            {error_struct === "true" && <div style={{ color: "red", fontSize: "15px" }}>Названия переменных повторяются!</div>}{/*ошибка при повтрении! */}

            {todostwo.map((todo) => {
              return (
                <ToDoTwo todo={todo} key={todo.id} removeTaskTwo={removeTaskTwo} />
              )
            })}
            <ToDoFormTwo check={check} />
            {todostwo.length > 0 && <p>
              <label>
                <input data-tooltip-id="my-tooltiptwo" data-tooltip-content="Тип структуры - массив" className="radio" type="radio" name="myRadio" value="array" onClick={() => { radios_("array") }} />
                array
              </label>
              <label style={{ float: "right", marginRight: "143px" }}>
                <input data-tooltip-id="my-tooltiptwo" data-tooltip-content="Тип структуры - сопоставление" className="radio" type="radio" name="myRadio" value="mapping" onClick={() => radios_("mapping")} />
                mapping
              </label>
            </p>}
            {radios === "array" && todostwo.length > 0 && <div > {struct} [] {struct}_ ; </div>}
            {radios === "mapping" && todostwo.length > 0 && <div > mapping (
              <select className={"text_" + color} value={connection} onChange={(e) => connection_(e.currentTarget.value)}>
                <option value='' hidden>Тип</option>
                <option style={{ color: "grey" }} value="string">string</option>
                <option style={{ color: "grey" }} value="uint">uint</option>
                <option style={{ color: "grey" }} value="bool">bool</option>
              </select>
              ={">"} {struct} ) {struct}_ ;
            </div>}

            {((connection !== "" && radios === "mapping") || radios === "array") && todostwo.length > 0 && <><br /><button className="button_write" onClick={() => { save(); setModalActive(false); STRUCT(""); setTODOStwo([]) }}>Добавить структуру</button><br /></>}
            {help === "Структура" && <><br />
              {help}
            </>}
          </div>}

          {modal_click === "Добавить функцию" && <div>
            пу,..пу,..пу, заварю ка кофейку...
          </div>}

          {modal_click === "Справка" && <div>
            <li className={"text_radio_" + color} onClick={() => { handleClick(0); setHelp("Контракт") }} style={{ color: activeIndex === 0 ? '#6d5bfd' : '' }}>Контракт</li><br />
            <li className={"text_radio_" + color} onClick={() => { handleClick(1); setHelp("Типы переменных") }} style={{ color: activeIndex === 1 ? '#6d5bfd' : '' }}>Типы переменных</li><br />
            <li className={"text_radio_" + color} onClick={() => { handleClick(2); setHelp("Операторы") }} style={{ color: activeIndex === 2 ? '#6d5bfd' : '' }}>Операторы</li><br />
            <li className={"text_radio_" + color} onClick={() => { handleClick(3); setHelp("Массив") }} style={{ color: activeIndex === 3 ? '#6d5bfd' : '' }}>Массив</li><br />
            <li className={"text_radio_" + color} onClick={() => { handleClick(4); setHelp("Структура") }} style={{ color: activeIndex === 4 ? '#6d5bfd' : '' }}>Структура</li><br />
            <li className={"text_radio_" + color} onClick={() => { handleClick(5); setHelp("Конструктор") }} style={{ color: activeIndex === 5 ? '#6d5bfd' : '' }}>Конструктор</li><br />
            <li className={"text_radio_" + color} onClick={() => { handleClick(6); setHelp("Мадификатор") }} style={{ color: activeIndex === 6 ? '#6d5bfd' : '' }}>Мадификатор</li><br />
            <li className={"text_radio_" + color} onClick={() => { handleClick(7); setHelp("Функция") }} style={{ color: activeIndex === 7 ? '#6d5bfd' : '' }}>Функция</li><br />
            <li className={"text_radio_" + color} onClick={() => { handleClick(8); setHelp("Циклы") }} style={{ color: activeIndex === 8 ? '#6d5bfd' : '' }}>Циклы</li><br />
            <li className={"text_radio_" + color} onClick={() => { handleClick(9); setHelp("Условие") }} style={{ color: activeIndex === 9 ? '#6d5bfd' : '' }}>Условие</li><br /><br />

            {activeIndex !== null && <>
              <center>{help}</center>
            </>}
          </div>}

          {modal_click === "Главная_Справка" && <div >
            <li className={"text_radio_" + color} onClick={() => { handleClick(0); setHelp("Выход из личного кабинета") }} style={{ color: activeIndex === 0 ? '#6d5bfd' : '' }}>Выйти из личного кабинета</li><br />
            <li className={"text_radio_" + color} onClick={() => { handleClick(1); setHelp("Сменить тему") }} style={{ color: activeIndex === 1 ? '#6d5bfd' : '' }}>Сменить тему</li><br />
            Контракты:<div style={{ marginLeft: "9px" }}>
              <li className={"text_radio_" + color} onClick={() => { handleClick(2); setHelp("Создать контракт") }} style={{ color: activeIndex === 2 ? '#6d5bfd' : '' }}>Создать контракт</li><br />
              <li className={"text_radio_" + color} onClick={() => { handleClick(3); setHelp("Удалить контракт") }} style={{ color: activeIndex === 3 ? '#6d5bfd' : '' }}>Удалить контракт</li><br />
              <li className={"text_radio_" + color} onClick={() => { handleClick(4); setHelp("Скачать контракт") }} style={{ color: activeIndex === 4 ? '#6d5bfd' : '' }}>Скачать контракт</li><br />
              <li className={"text_radio_" + color} onClick={() => { handleClick(5); setHelp("Открыть контракт") }} style={{ color: activeIndex === 5 ? '#6d5bfd' : '' }}>Открыть контракт</li><br />
              <li className={"text_radio_" + color} onClick={() => { handleClick(6); setHelp("Добавить структуру") }} style={{ color: activeIndex === 6 ? '#6d5bfd' : '' }}>Добавить структуру</li><br />
              <li className={"text_radio_" + color} onClick={() => { handleClick(7); setHelp("Удалить структуру") }} style={{ color: activeIndex === 7 ? '#6d5bfd' : '' }}>Удалить структуру</li><br />
              <li className={"text_radio_" + color} onClick={() => { handleClick(8); setHelp("Добавить функцию") }} style={{ color: activeIndex === 8 ? '#6d5bfd' : '' }}>Добавить функцию</li><br />
              <li className={"text_radio_" + color} onClick={() => { handleClick(9); setHelp("Удалить функцию") }} style={{ color: activeIndex === 9 ? '#6d5bfd' : '' }}>Удалить функцию</li><br />
              <li className={"text_radio_" + color} onClick={() => { handleClick(10); setHelp("Копировать код контракта") }} style={{ color: activeIndex === 10 ? '#6d5bfd' : '' }}>Копировать код контракта</li><br />
              <li className={"text_radio_" + color} onClick={() => { handleClick(11); setHelp("Справка по коду контракта") }} style={{ color: activeIndex === 11 ? '#6d5bfd' : '' }}>Справка по коду контракта</li><br />
              <li className={"text_radio_" + color} onClick={() => { handleClick(12); setHelp("Очистить поле компиляции") }} style={{ color: activeIndex === 12 ? '#6d5bfd' : '' }}>Очистить поле компиляции</li>
            </div>
            Компиляция:<div style={{ marginLeft: "9px" }}>...<br /></div>
            Рукописный код:<div style={{ marginLeft: "9px" }}>...<br /></div>
            <br />
            {activeIndex !== null && <>
              <center>{help}</center>
            </>}
          </div>}

        </Modal>
      </div>
    </>
  );
}

export default Page_2;