import React, { useState, useRef, useEffect } from "react";
import { ScrollSync, ScrollSyncPane } from 'react-scroll-sync';
//подключение роутинга
import { Link } from 'react-router-dom';
//подключение копирования
import { CopyToClipboard } from 'react-copy-to-clipboard';
//подключение подсказки при наведении на объекте
import 'react-tooltip/dist/react-tooltip.css';
import { Tooltip } from 'react-tooltip';
//подключение списка
import ToDo from "./todo/ToDo";
import ToDoForm from "./todo/ToDoForm";
import ToDoTwo from "./todo/ToDoTwo";
import ToDoFormTwo from "./todo/ToDoFormTwo";
import ToDoThree from "./todo/ToDoThree";
import ToDoFive from "./todo/ToDoFive";
//подключение модального окна
import Modal from "./modal_window/Modal";
//запросы
import axios from 'axios';
//подключение svg, png, gif
import user from './pictures/user.svg';
import moon from './pictures/moon.svg';
import copy from './pictures/copy.svg';
import code from './pictures/code.svg';
import code_black from './pictures/code_black.svg';
import code_active from './pictures/code_active.svg';
import box from './pictures/box.svg';
import box_black from './pictures/box_black.svg';
import box_active from './pictures/box_active.svg';
import copy_black from './pictures/copy_black.svg';
import document from './pictures/document.svg';
import document_black from './pictures/document_black.svg';
import document_active from './pictures/document_active.svg';
import add_square from './pictures/add_square.svg';
import add_square_black from './pictures/add_square_black.svg';
import lamp_on from './pictures/lamp_on.svg';
import lamp_on_black from './pictures/lamp_on_black.svg';
import eraser from './pictures/eraser.svg';
import eraser_black from './pictures/eraser_black.svg';
import book from './pictures/book.svg';
import book_black from './pictures/book_black.svg';
import book_active from './pictures/book_active.svg';
import play from './pictures/play.svg';
import play_black from './pictures/play_black.svg';
import play_active from './pictures/play_active.svg';
import documentwrite from './pictures/documentwrite.svg';
import documentblack from './pictures/documentblack.svg';
import documentactive from './pictures/documentactive.svg';
import logo from './pictures/logo.png';
import trash_black from './pictures/trash_black.svg';
import trash from './pictures/trash.svg';
import sun from './pictures/sun.svg';
//скриншоты
import one from './scrin/one.png';
import two from './scrin/two.png';
import three from './scrin/three.png';
import four from './scrin/four.png';
import five from './scrin/five.png';
import six from './scrin/six.png';
import seven from './scrin/seven.png';
import eight from './scrin/eight.png';
import nine from './scrin/nine.png';
import ten from './scrin/ten.png';
import eleven from './scrin/eleven.png';
import twelve from './scrin/twelve.png';
import thirteen from './scrin/thirteen.png';
import fourteen from './scrin/fourteen.png';
import fifteen from './scrin/fifteen.png';
import sixteen from './scrin/sixteen.png';
import seventeen from './scrin/seventeen.png';
import eighteen from './scrin/eighteen.png';
import nineteen from './scrin/nineteen.png';
import twenty from './scrin/twenty.png';
import twenty_one from './scrin/twenty_one.png';
import twenty_two from './scrin/twenty_two.png';
import twenty_three from './scrin/twenty_three.png';
import twenty_four from './scrin/twenty_four.png';
import twenty_five from './scrin/twenty_five.png';
import twenty_six from './scrin/twenty_six.png';
import twenty_seven from './scrin/twenty_seven.png';
import twenty_eight from './scrin/twenty_eight.png';
import twenty_nine from './scrin/twenty_nine.png';

function Page_2() {
  const co = sessionStorage.getItem("color");
  const [color, col] = useState(co); // тема
  sessionStorage.setItem("color", color);
  //CONTRACT
  const [text, t] = useState("");//название контракта
  sessionStorage.setItem("text", text);
  const [contract, c] = useState("");//код контракта
  const [create, create_] = useState("c");//открывает / закрывает создание контракта
  sessionStorage.setItem("create", create);
  const [todos, setTODOS] = useState([]);//просмотр контрактов
  const [compilation, com] = useState("");//просмотр компиляции
  //MODAL WINDOW
  const [modal_click, modal_click_] = useState("");//выбор содержимого модального окна
  const [modalActive, setModalActive] = useState(false);//подключение модального окна
  //STRUCT
  const [todostwo, setTODOStwo] = useState([]);//просмотр переменных структуры
  sessionStorage.setItem("todostwo", todostwo);
  const [createtwo, createtwo_] = useState("c");//открывает / закрывает создание переменной
  sessionStorage.setItem("createtwo", createtwo);
  const [struct, STRUCT] = useState("");//нзвание структуры
  const [structs, s] = useState("");//структуры кода
  sessionStorage.setItem("structs", structs);
  const [error_struct, error_struct_] = useState("false");//ошибка, если название элементов совпадает
  const [connection, connection_] = useState("");//тип связи для mapping
  const [error, error_] = useState("false");
  const [radios, radios_] = useState("");// array || mapping
  //МЕНЮ
  const [menu, menu_] = useState("");
  //справка
  const [help, setHelp] = useState("");
  const [activeIndex, setActiveIndex] = useState(null);
  //добавление функций
  const [todosthree, setTODOSThree] = useState([]);
  const [start, setstart] = useState("c");
  //контекстное меню----
  const [showMenu, setShowMenu] = useState(false);
  const [menuPosition, setMenuPosition] = useState({ x: 0, y: 0 });
  const menuRef = useRef(null);
  //удаление функции / структуры
  const [todosfive, setTODOSfive] = useState([]);
  const [fanctions, setfanctions] = useState("");
  sessionStorage.setItem("fanctions", fanctions);
  //пользователь
  const login = sessionStorage.getItem("login");
  //Действующая структура. элементы, типы элементов
  const [run_element, setRun_element] = useState([]);
  const [run_tip_element, run_tip_elements] = useState([]);

  useEffect(() => {
    axios.post('http://localhost:3001/out', { login })
      .then(response => {
        col(response.data.color);
      })
      .catch(error => {
        console.error(error);
      });
  }, []);

  async function click(e) {//функция открыть / закрыть контракт
    if (e === "Создать контракт") {
      if (create === "c")
        create_("o");
      else
        create_("c");
    }
    if (e === "Добавить переменную") {
      if (createtwo === "c")
        createtwo_("o");
      else
        createtwo_("c");
    }
    if (e === "Контракты") {
      loadContracts();
    }

    if (e === "Компиляция") {
      setTODOS([]);
    }
  }
  // Создайте функцию для загрузки контрактов
  async function loadContracts() {
    try {
      const response = await axios.post('http://localhost:3001/user-contracts', { login: login });
      const contractNames = response.data.contractNames;

      const newTodos = contractNames.filter(contractName => !todos.some(todo => todo.task === contractName))
        .map(contractName => ({
          id: Math.random().toString(36).substr(2, 9),
          task: contractName,
          complete: false
        }));

      setTODOS(prevTodos => [...prevTodos, ...newTodos]);
      create_("c");
    } catch (error) {
      console.error(error);
    }
  }
  async function COLORS() {//функция смена темы
    if (color === "write") {
      axios.post('http://localhost:3001/update-theme', { login: login, theme: "black" })
        .then(response => {
          col("black");
        })
        .catch(error => {
          console.error(error);
        });
    }
    else {
      axios.post('http://localhost:3001/update-theme', { login: login, theme: "write" })
        .then(response => {
          col("write");
        })
        .catch(error => {
          console.error(error);
        });
    }
  }
  async function addTask(userinput) {
    if (userinput) {
      // Проверка на уникальность имени контракта
      const isContractNameUnique = await checkContractNameUnique(userinput);

      if (!isContractNameUnique) {
        console.error('Контракт с таким именем уже существует');
        return; // Завершаем выполнение функции
      }

      const newItem = {
        id: Math.random().toString(36).substr(2, 9),
        task: userinput,
        complete: false
      };

      // Отправляем запрос на сервер для добавления контракта
      axios.post('http://localhost:3001/add_contract', { login: login, name: userinput })
        .then(response => {
          // Если контракт успешно добавлен, добавляем элемент в список
          setTODOS([...todos, newItem]);
          create_("c");
        })
        .catch(error => {
          console.error('Ошибка при добавлении контракта:', error);
          // Обработка ошибки при добавлении контракта
        });
    }
  }
  async function checkContractNameUnique(contractName) {
    // Отправляем запрос на сервер для получения списка контрактов пользователя
    const response = await axios.post('http://localhost:3001/user-contracts', { login: login });

    const contractNames = response.data.contractNames;

    // Проверяем, есть ли среди контрактов контракт с таким же именем
    return !contractNames.includes(contractName);
  }

  async function removeTask(id, e) {//функция удаления элемента списка
    setTODOS([...todos.filter((todo) => todo.id !== id)]);
    if (e === text) { // если удаляем контракт, а его код открыт, то он обнуляется
      t(""); c(""); s(""); STRUCT("");
    }
  }
  async function tex(e) {//функция заполнения кода контракта
    s(""); setRun_element([]); run_tip_elements([]);
    if (e !== text) {
      t(e); c("// SPDX-License-Identifier: GPL-3.0\npragma solidity >=0.8.2 <0.9.0;\n\ncontract " + e.charAt(0).toUpperCase() + e.slice(1) + " {\n\n");
      axios.post('http://localhost:3001/view_struct', { login: login, name_Contract: e })
        .then(response => {
          const matchingStructs = response.data.struct;

          if (matchingStructs.length === 0) {
            console.log('Записей не найдено');
          } else {
            console.log('Найденные структуры:');
            matchingStructs.forEach(struct => {
              setRun_element(prevRunElement => [...prevRunElement, struct.name]);
              let allStructNames = '';

              matchingStructs.forEach(struct => {
                allStructNames += "struct " + struct.name + " {\n";
                for (let i = 0; i < struct.numElements; i++) {
                  allStructNames += " " + struct.types[i] + " " + struct.elementNames[i] + ";\n";
                }
                if (struct.nameMapping === "array")
                  allStructNames += "}\n" + struct.name + "[] " + struct.name + "_;\n\n";
                if (struct.nameMapping === "mapping")
                  allStructNames += "}\nmapping (" + struct.typeMapping + " => " + struct.name + ") " + struct.name + "_;\n\n";
              });

              s(allStructNames);
            });
          }
        })
        .catch(error => {
          console.error(error);
        });
      axios.get('http://localhost:3001/view_functions', {
        params: { login: login, name_Contract: e }
      })
        .then(response => {
          const matchingFunctions = response.data.functions;
          let allFunctionNames = '';
          matchingFunctions.forEach(functions => {
            run_tip_elements(run_tip_element => [...run_tip_element, functions.name]);
            allFunctionNames += functions.text + "\n\n";
          });
          setfanctions(allFunctionNames);

        })
        .catch(error => {
          console.error(error);
        });
    }
    else {
      t(""); c("");
    }
  }
  //struct
  async function addTaskTwo(userinput, usertipe) {//Функция добавления элемента в список
    if (userinput && usertipe) {
      const newItem = {
        id: todostwo.length,
        task: userinput,
        tip: usertipe,
        complete: false
      }
      setTODOStwo([...todostwo, newItem]); createtwo_("c"); error_struct_("false"); error_("false");
    }
  }
  async function removeTaskTwo(id) {//функция удаления элемента списка
    setTODOStwo([...todostwo.filter((todo) => todo.id !== id)])
  }
  async function save() {
    // Создаем структуру только один раз перед циклом
    try {
      const response = await axios.post('http://localhost:3001/add_struct', {
        name_Contract: text,
        login: login,
        name: struct,
        numElements: todostwo.length, // Здесь указываем общее количество элементов
        typeMapping: connection,
        nameMapping: radios,
      });
      setRun_element([...run_element, struct]);
      for (const e of todostwo) {
        try {
          await axios.post('http://localhost:3001/add_element_struct', {
            name_Contract: text,
            login: login,
            name: struct,
            types: e.tip,
            elementNames: e.task,
          });
          console.log('Элемент успешно добавлен:', e.task);
        } catch (error) {
          console.error('Ошибка при отправке данных для элемента', e.task, ':', error);
        }
      }

      // Обрабатываем ответ от сервера.
      console.log(response.data);

      //просмотр данных структуры
      let str = structs + "struct " + struct + " {\n";
      todostwo.map((e) => {
        str += " " + e.tip + " " + e.task + ";\n";
      })
      if (radios === "array")
        str += "}\n" + struct + "[] " + struct + "_;\n\n";
      if (radios === "mapping")
        str += "}\nmapping (" + connection + " => " + struct + ") " + struct + "_;\n\n";
      s(str);
      error_struct_("false"); createtwo_("c"); setTODOStwo([]); error_("false"); connection_(""); radios_("");

    } catch (error) {
      console.error('Ошибка при отправке данных:', error); com(compilation + "\nОшибка, структуры с одинаковыми названиями не могут находиться в одном контракте!")
    }
  }
  //проверка на повтрение названий элементов структуры
  async function check(userinput, usertipe) {
    let str = "false";
    todostwo.map((e) => {
      if (e.task === userinput) {
        str = "true";
        error_struct_("true");
      }
    })
    if (str === "false") {
      addTaskTwo(userinput, usertipe); error_struct_("false");
    }
  }
  //очистка поля
  async function Eraser(e) {
    if (e === "Добавить структуру") {
      STRUCT(""); error_struct_("false"); createtwo_("c"); setTODOStwo([]); error_("false"); connection_(""); radios_("");
    }
  }
  //ограничение на вводимые символы
  function onChangeTagInput(e) {
    STRUCT(e.target.value.replace(/[^a-z_\s]/gi, ""));
    var regexp = /[a-z_\s]+$/i
    if ((!e.target.value || regexp.test(e.target.value)))
      error_("false");
    else
      error_("true");
  }
  //Справка
  const handleClick = (index) => {
    setActiveIndex(index);
  }
  //Добавление функций
  async function addTaskThree() { com(compilation + "\nКод скомпилирован")
    try {
      const response = await axios.get('http://localhost:3001/view_functions', { params: { login: login, name_Contract: text } });
      const matchingFunctions = response.data.functions;
  
      for (const functions of matchingFunctions) {
        const newItem = {
          id: Math.random().toString(36).substr(2, 9),
          task: functions.name,
          complete: false
        };
        await setTODOSThree(prevItems => [...prevItems, newItem]);
      }
  
      setstart("o");
    } catch (error) {
      console.error(error);
    }
  }
  //Удалить структуру / функцию
  async function addTaskFive(e) {//Функция добавления элемента в список
    if (e === "Удалить структуру") {
      for (let i = 0; i < run_element.length; i++) {
        const newItem = {
          id: Math.random().toString(36).substr(2, 9),
          name: run_element[i],
          complete: false
        }
        await setTODOSfive(prevItems => [...prevItems, newItem]);
      }
    }
    if (e === "Удалить функцию") {
      for (let i = 0; i < run_tip_element.length; i++) {
        const newItem = {
          id: Math.random().toString(36).substr(2, 9),
          name: run_tip_element[i],
          complete: false
        }
        await setTODOSfive(prevItems => [...prevItems, newItem]);
      }
    }

  }
  async function removeTaskFive(id, name, e) {
    if (e === "Удалить структуру") {
      axios.post('http://localhost:3001/remove_struct', { login: login, name_Contract: text, name: name })
        .then(response => {
        })
        .catch(error => {
          console.error(error);
        });

      setTODOSfive([...todosfive.filter((todo) => todo.id !== id)]);
      tex(text);
    }
    if (e === "Удалить функцию") {
      axios.post('http://localhost:3001/remove_function', { login: login, name_Contract: text, name: name })
        .then(response => {
        })
        .catch(error => {
          console.error(error);
        });

      setTODOSfive([...todosfive.filter((todo) => todo.id !== id)]);
      tex(text);
    }
  }

  const [activeIndex2, setActiveIndex2] = useState(2);
  const handleButtonClick2 = (index) => {
    setActiveIndex2(index);
  };
  async function saveF(e, name) {
    //просмотр данных функции
    let fnc = fanctions;
    axios.post('http://localhost:3001/add_function', { login: login, name_Contract: text, text: e, name: name })
      .then(response => {
        setfanctions(fnc + e + "\n\n"); run_tip_elements(run_tip_element => [...run_tip_element, name]);
      })
      .catch(error => {
        console.error(error); com(compilation + "\nОшибка, функции с одинаковыми названиями не могут находиться в одном контракте!")
      });
  }

  //контекстное меню----
  function handleContextMenu(event) {
    event.preventDefault(); // отменяем стандартное контекстное меню браузера
    setShowMenu(true);
    setMenuPosition({ x: event.clientX, y: event.clientY });
  }

  function handleClickTwo(event) {
    // если клик был сделан вне контекстного меню, закрываем его
    if (menuRef.current && !menuRef.current.contains(event.target)) {
      setShowMenu(false);
    }
  }
  //
  return (
    <>
      <div onClick={handleClickTwo} className={color} style={{ backgroundImage: `url(${logo})`, backgroundSize: "auto", backgroundRepeat: "no-repeat", backgroundPosition: "center" }}>
        <Tooltip id="my-tooltip" />{/*подсказки при наведении на объекте дописывается data-tooltip-id="my-tooltip" data-tooltip-content="Комментарий*/}

        <header className="navbar">
          <button style={{ float: "right", marginRight: "20px" }} className="text" data-tooltip-id="my-tooltip" data-tooltip-content="Сменить тему" onClick={() => COLORS()}><img src={color === "write" ? moon : sun} width="25" alt="" /></button>
          <Link to="/Page_1"><button className="text" style={{ marginRight: "20px" }} data-tooltip-id="my-tooltip" data-tooltip-content="Выйти из личного кабинета"><img src={user} width="25" alt="" /></button></Link>&nbsp;
        </header>

        <div style={{ display: "flex" }}>
          {/*пред-левый блок*/}
          {color === "write" && <div className={"block_" + color + "_2"} style={{ float: "right" }}>
            <div style={{ float: "left", marginLeft: "5px" }}><br />
              <button className="text" data-tooltip-id="my-tooltip" data-tooltip-content="Справка" onClick={() => { setModalActive(true); modal_click_("Главная_Справка"); setHelp(""); handleClick(null) }}><img src={modal_click === "Главная_Справка" && modalActive === true ? book_active : book} /></button><br /><br /><br />
              <button className="text" data-tooltip-id="my-tooltip" data-tooltip-content="Контракты" onClick={() => { menu_("Контракты"); setTODOSThree([]); setstart("c"); handleButtonClick2(0); click("Контракты") }}><img src={activeIndex2 === 0 ? document_active : document_black} width="25" alt="" /></button><br /><br />
              {text !== "" && <><button className="text" data-tooltip-id="my-tooltip" data-tooltip-content="Компиляция" onClick={() => { menu_("Компиляция"); handleButtonClick2(1); click("Компиляция") }}><img src={activeIndex2 === 1 ? play_active : play} width="25" alt="" /></button><br /><br /></>}
            </div>
          </div>}
          {color === "black" && <div className={"block_" + color + "_2"} style={{ float: "right" }}>
            <div style={{ float: "left", marginLeft: "5px" }}><br />
              <button className="text" data-tooltip-id="my-tooltip" data-tooltip-content="Справка" onClick={() => { setModalActive(true); modal_click_("Главная_Справка"); setHelp(""); handleClick(null) }}><img src={modal_click === "Главная_Справка" && modalActive === true ? book_active : book_black} width="25" alt="" /></button><br /><br /><br />
              <button className="text" data-tooltip-id="my-tooltip" data-tooltip-content="Контракты" onClick={() => { menu_("Контракты"); setTODOSThree([]); setstart("c"); handleButtonClick2(0); click("Контракты") }}><img src={activeIndex2 === 0 ? document_active : document} width="25" alt="" /></button><br /><br />
              {text !== "" && <><button className="text" data-tooltip-id="my-tooltip" data-tooltip-content="Компиляция" onClick={() => { menu_("Компиляция"); handleButtonClick2(1); click("Компиляция") }}><img src={activeIndex2 === 1 ? play_active : play_black} width="25" alt="" /></button><br /><br /></>}
            </div>
          </div>}

          {/*левый блок*/}
          {/*Контракты*/}
          {color === "write" && menu === "Контракты" && <div className={"block_" + color} style={{ float: "left" }}><br />
            <div style={{ float: "right", marginRight: "20px" }}>
              <button className="text" data-tooltip-id="my-tooltip" data-tooltip-content="Создать контракт" onClick={() => click("Создать контракт")}><img src={create === "o" ? documentactive : documentwrite} width="25" alt="" /></button>
            </div><br /><br />
            {/*Список контрактов*/}
            <div >
              {todos.map((todo) => {
                return (<ToDo todo={todo} key={todo.id} removeTask={removeTask} tex={tex} />
                )
              })}
              <ToDoForm addTask={addTask} />
            </div>
          </div>}
          {color === "black" && menu === "Контракты" && <div className={"block_" + color} style={{ float: "left" }}><br />
            <div text={text} style={{ float: "right", marginRight: "20px" }}>
              <button className="text" data-tooltip-id="my-tooltip" data-tooltip-content="Создать контракт" onClick={() => click("Создать контракт")}><img src={create === "o" ? documentactive : documentblack} width="25" alt="" /></button>
            </div><br /><br />
            {/*Список контрактов */}
            <div >
              {todos.map((todo) => {
                return (
                  <ToDo todo={todo} key={todo.id} removeTask={removeTask} tex={tex} />
                )
              })}
              <ToDoForm addTask={addTask} />
            </div>
          </div>}
          {/*Компиляция*/}
          {color === "write" && menu === "Компиляция" && <div className={"block_" + color}>
            {start === "c" && <button className="button_write" onClick={addTaskThree}>
              Компилировать
            </button>}
            {start === "o" && <><br /></>}
            {start === "o" && <button style={{ float: "right", marginRight: "20px" }} className="text" data-tooltip-id="my-tooltip" data-tooltip-content="Удалить компиляцию" onClick={() => { setstart("c"); setTODOSThree([]); }}><img src={trash} width="25" alt="" /></button>}
            <br /><br />
            {todosthree.map((todo) => {
              {/*Импуты */ }
              return (
                <ToDoThree todo={todo} key={todo.id} />
              )
            })}
          </div>}
          {color === "black" && menu === "Компиляция" && <div className={"block_" + color}>
            {start === "c" && <button className="button_write" onClick={addTaskThree}>
              Компилировать
            </button>}
            {start === "o" && <><br /></>}
            {start === "o" && <button style={{ float: "right", marginRight: "20px" }} className="text" data-tooltip-id="my-tooltip" data-tooltip-content="Удалить компиляцию" onClick={() => { setstart("c"); setTODOSThree([]); }}><img src={trash_black} width="25" alt="" /></button>}
            <br /><br />
            {todosthree.map((todo) => {
              {/*Импуты */ }
              return (
                <ToDoThree todo={todo} key={todo.id} />
              )
            })}
          </div>}

          {/*область для кода*/}
          {text !== "" && <div className="textarea-container">
            {menu === "Контракты" && <div onContextMenu={handleContextMenu}>
              <ScrollSync>
                <div className="code-editor" style={{ resize: "vertical", overflow: "hidden", cursor: 'ns-resize', maxHeight: "70vh" }}>
                  <ScrollSyncPane>
                    <div className={"line-numbers_" + color} style={{ height: "66.5vh", maxheight: "75.5vh" }}>
                      {(contract + structs + fanctions + "\n}").split('\n').map((_, i) => (
                        <div key={i}>{i + 1}</div>
                      ))}
                    </div>
                  </ScrollSyncPane>
                  <ScrollSyncPane>
                    <textarea
                      className={"textarea_" + color}
                      style={{ width: "148vh", height: "66.3vh", maxheight: "75.5vh" }}
                      type="text"
                      disabled
                      autoFocus={true}
                      value={contract + structs + fanctions + "\n}"}
                      onChange={(e) => c(e.target.value)}
                    />
                  </ScrollSyncPane>
                </div>
              </ScrollSync></div>}
            {menu === "Компиляция" && <div>
              <ScrollSync>
                <div className="code-editor" style={{ resize: "vertical", overflow: "hidden", cursor: 'ns-resize', maxHeight: "70vh" }}>
                  <ScrollSyncPane>
                    <div className={"line-numbers_" + color} style={{ height: "66.5vh", maxheight: "75.5vh" }}>
                      {(contract + structs + fanctions + "\n}").split('\n').map((_, i) => (
                        <div key={i}>{i + 1}</div>
                      ))}
                    </div>
                  </ScrollSyncPane>
                  <ScrollSyncPane>
                    <textarea
                      className={"textarea_" + color}
                      style={{ width: "148vh", height: "66.3vh", maxheight: "75.5vh" }}
                      type="text"
                      disabled
                      autoFocus={true}
                      value={contract + structs + fanctions + "\n}"}
                      onChange={(e) => c(e.target.value)}
                    />
                  </ScrollSyncPane>
                </div>
              </ScrollSync></div>}
            <textarea className={"textarea_" + color} style={{ width: "155vh", borderTop: '2px solid #c0c0c040' }} type="text" value={compilation} onChange={(e) => com(e.currentTarget.value)} />
            {showMenu && (
              <div ref={menuRef} className="context-menu" style={{ position: 'absolute', left: menuPosition.x, top: menuPosition.y }}>
                <ul>
                  <li onClick={() => { setModalActive(true); modal_click_("Удалить структуру"); setShowMenu(false); setTODOSfive([]); addTaskFive("Удалить структуру"); }}>Удалить структуру</li>
                  <li onClick={() => { setModalActive(true); modal_click_("Удалить функцию"); setShowMenu(false); setTODOSfive([]); addTaskFive("Удалить функцию"); }}>Удалить функцию</li>
                </ul>
              </div>
            )}
          </div>}

          {/*правый блок*/}
          {color === "write" && text !== "" && <div className={"block_" + color + "_2"} style={{ float: "right" }}>
            {menu !== "Компиляция" && <div style={{ float: "left", marginLeft: "5px" }}><br />
              {menu === "Контракты" && <><button className="text" data-tooltip-id="my-tooltip" data-tooltip-content="Добавить структуру" onClick={() => { setModalActive(true); modal_click_("Добавить структуру"); setHelp(""); }}><img src={modal_click === "Добавить структуру" && modalActive === true ? box_active : box} width="25" alt="" /></button><br /><br /></>}
              {menu === "Контракты" && <><button className="text" data-tooltip-id="my-tooltip" data-tooltip-content="Добавить функцию" onClick={() => { setModalActive(true); modal_click_("Добавить функцию") }}><img src={modal_click === "Добавить функцию" && modalActive === true ? code_active : code} width="25" alt="" /></button><br /><br /></>}
              <button className="text" data-tooltip-id="my-tooltip" data-tooltip-content="Справка" onClick={() => { setModalActive(true); modal_click_("Справка"); setHelp(""); handleClick(null) }}><img src={modal_click === "Справка" && modalActive === true ? book_active : book} width="25" alt="" /></button><br /><br /><br />
              <CopyToClipboard text={contract + structs + fanctions + "\n}"}><button className="text" data-tooltip-id="my-tooltip" data-tooltip-content="Копировать код"><img src={copy_black} width="25" alt="" /></button></CopyToClipboard><br /><br />
              <br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br />
              {compilation !== "" && <button className="text" data-tooltip-id="my-tooltip" data-tooltip-content="Очистить" onClick={() => { com("") }}><img src={eraser} width="25" alt="" /></button>}
            </div>}
            {menu === "Компиляция" && <div style={{ float: "left", marginLeft: "5px" }}>
              <br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br />
              {compilation !== "" && <button className="text" data-tooltip-id="my-tooltip" data-tooltip-content="Очистить" onClick={() => { com("") }}><img src={eraser} width="25" alt="" /></button>}</div>}
          </div>}
          {color === "black" && text !== "" && <div className={"block_" + color + "_2"} style={{ float: "right" }}>
            {menu !== "Компиляция" && <div style={{ float: "left", marginLeft: "5px" }}><br />
              {menu === "Контракты" && <><button className="text" data-tooltip-id="my-tooltip" data-tooltip-content="Добавить структуру" onClick={() => { setModalActive(true); modal_click_("Добавить структуру"); setHelp(""); }}><img src={modal_click === "Добавить структуру" && modalActive === true ? box_active : box_black} width="25" alt="" /></button><br /><br /></>}
              {menu === "Контракты" && <><button className="text" data-tooltip-id="my-tooltip" data-tooltip-content="Добавить функцию" onClick={() => { setModalActive(true); modal_click_("Добавить функцию") }}><img src={modal_click === "Добавить функцию" && modalActive === true ? code_active : code_black} width="25" alt="" /></button><br /><br /></>}
              <button className="text" data-tooltip-id="my-tooltip" data-tooltip-content="Справка" onClick={() => { setModalActive(true); modal_click_("Справка"); setHelp(""); handleClick(null) }}><img src={modal_click === "Справка" && modalActive === true ? book_active : book_black} width="25" alt="" /></button><br /><br /><br />
              <CopyToClipboard text={contract + structs + fanctions + "\n}"}><button className="text" data-tooltip-id="my-tooltip" data-tooltip-content="Копировать код"><img src={copy} width="25" alt="" /></button></CopyToClipboard><br /><br />
              <br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br />
              {compilation !== "" && <button className="text" data-tooltip-id="my-tooltip" data-tooltip-content="Очистить" onClick={() => { com("") }}><img src={eraser_black} width="25" alt="" /></button>}
            </div>}
            {menu === "Компиляция" && <div style={{ float: "left", marginLeft: "5px" }}>
              <br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br />
              {compilation !== "" && <button className="text" data-tooltip-id="my-tooltip" data-tooltip-content="Очистить" onClick={() => { com("") }}><img src={eraser_black} width="25" alt="" /></button>}</div>}
          </div>}
        </div>

        {/*модальное окно*/}
        <Modal active={modalActive} setActive={setModalActive} style={{ padding: "0 20px", paddingTop: "20px", paddingBottom: "20px" }}>
          <Tooltip id="my-tooltiptwo" />

          {modal_click === "Добавить структуру" && <div>
            {color === "write" && <button style={{ float: "right" }} className="text" data-tooltip-id="my-tooltiptwo" data-tooltip-content="Справка" onClick={() => { setHelp(help === "Структура" ? '' : 'Структура') }}><img src={help === "Структура" ? book_active : book} /></button>}
            {color === "black" && <button style={{ float: "right" }} className="text" data-tooltip-id="my-tooltiptwo" data-tooltip-content="Справка" onClick={() => { setHelp(help === "Структура" ? '' : 'Структура') }}><img src={help === "Структура" ? book_active : book_black} width="25" alt="" /></button>}
            {color === "write" && struct !== "" && <button style={{ float: "right" }} className="text" data-tooltip-id="my-tooltiptwo" data-tooltip-content="Очистить" onClick={() => Eraser("Добавить структуру")}><img src={eraser} width="25" alt="" /></button>}
            {color === "black" && struct !== "" && <button style={{ float: "right" }} className="text" data-tooltip-id="my-tooltiptwo" data-tooltip-content="Очистить" onClick={() => Eraser("Добавить структуру")}><img src={eraser_black} width="25" alt="" /></button>}
            {error === "true" && <div style={{ color: "red", fontSize: "15px" }}>Может содержать только a-z, _</div>}<br />{error === "false" && <br />}
            <div style={{ display: "flex", alignItems: "center" }}><br />
              <input className="inputss" type="text" autoFocus={true} placeholder="Название структуры" value={struct} onChange={(e) => onChangeTagInput(e)} />&nbsp;&nbsp;
              {struct !== "" && <div>
                {color === "write" && todostwo.length < 7 && <button className="text" data-tooltip-id="my-tooltiptwo" data-tooltip-content="Добавить переменную" onClick={() => { click("Добавить переменную"); error_struct_("false"); error_("false") }}><img src={add_square} width="25" alt="" /></button>}
                {color === "black" && todostwo.length < 7 && <button className="text" data-tooltip-id="my-tooltiptwo" data-tooltip-content="Добавить переменную" onClick={() => { click("Добавить переменную"); error_struct_("false"); error_("false") }}><img src={add_square_black} width="25" alt="" /></button>}
                {color === "write" && todostwo.length === 7 && <button style={{ float: "right" }} className={"text"} data-tooltip-id="my-tooltiptwo" data-tooltip-content="Структура может содержать не более 7 элементов!" ><img src={lamp_on} width="25" alt="" /></button>}
                {color === "black" && todostwo.length === 7 && <button style={{ float: "right" }} className={"text"} data-tooltip-id="my-tooltiptwo" data-tooltip-content="Структура может содержать не более 7 элементов!" ><img src={lamp_on_black} width="25" alt="" /></button>}
              </div>}
            </div>

            {error_struct === "false" && <br />}
            {error_struct === "true" && <div style={{ color: "red", fontSize: "15px" }}>Названия переменных повторяются!</div>}{/*ошибка при повтрении! */}

            {todostwo.map((todo) => {
              return (
                <ToDoTwo todo={todo} key={todo.id} removeTaskTwo={removeTaskTwo} />
              )
            })}
            <ToDoFormTwo check={check} />
            {todostwo.length > 0 && <p>
              <label>
                <input data-tooltip-id="my-tooltiptwo" data-tooltip-content="Тип структуры - массив" className="radio" type="radio" name="myRadio" value="array" onClick={() => { radios_("array") }} />
                array
              </label>
              <label style={{ float: "right", marginRight: "143px" }}>
                <input data-tooltip-id="my-tooltiptwo" data-tooltip-content="Тип структуры - отображения" className="radio" type="radio" name="myRadio" value="mapping" onClick={() => radios_("mapping")} />
                mapping
              </label>
            </p>}
            {radios === "array" && todostwo.length > 0 && <div > {struct} [] {struct}_ ; </div>}
            {radios === "mapping" && todostwo.length > 0 && <div > mapping (
              <select className={"text_" + color} value={connection} onChange={(e) => connection_(e.currentTarget.value)}>
                <option value='' hidden>Тип</option>
                <option style={{ color: "grey" }} value="string">string</option>
                <option style={{ color: "grey" }} value="uint">uint</option>
                <option style={{ color: "grey" }} value="bool">bool</option>
              </select>
              ={">"} {struct} ) {struct}_ ;
            </div>}

            {((connection !== "" && radios === "mapping") || radios === "array") && todostwo.length > 0 && <><br /><button className="button_write" onClick={() => { save(); setModalActive(false); STRUCT(""); setTODOStwo([]) }}>Добавить структуру</button><br /></>}
            {help === "Структура" && <><br />
              &nbsp;&nbsp;Solidity позволяет определять пользовательские структуры, которые могут содержать несколько полей с различными типами данных. Структуры полезны для создания более сложных объектов данных.<br /><br />
              <div style={{ backgroundColor: "#6c58fd1a", padding: "10px" }}>
                struct Person &#123;<br />
                &nbsp;&nbsp;string name;<br />
                &nbsp;&nbsp;uint age;<br />
                &#125;<br />
                Person [] myPerson;<br /><br />
                struct Book &#123;<br />
                &nbsp;&nbsp;string name;<br />
                &#125;<br />
                mapping(uint =&gt; Book) Books;
              </div><br />
              &nbsp;&nbsp;Способы хранения и организации данных в структуре:<br /><br />
              <div style={{ backgroundColor: "#6c58fd1a", padding: "10px" }}>
                mapping(uint =&gt; Book) Books;
              </div><br />
              &nbsp;&nbsp;В представленном коде объявлено отображение &#123;mapping&#125; с именем <span style={{ fontWeight: 'bold' }}>Books</span>, которое сопоставляет значения типа <span style={{ fontWeight: 'bold' }}>string</span> (строка) с объектами типа <span style={{ fontWeight: 'bold' }}>Book</span>.<br /><br />
              &nbsp;&nbsp;Отображение Books используется для создания ассоциации между строковыми ключами (например, названиями книг) и объектами типа <span style={{ fontWeight: 'bold' }}>Book</span>. Каждому ключу типа <span style={{ fontWeight: 'bold' }}>string</span> соответствует значение типа <span style={{ fontWeight: 'bold' }}>Book</span>.<br /><br />
              &nbsp;&nbsp;В контексте данного кода предполагается, что существует определение структуры или класса <span style={{ fontWeight: 'bold' }}>Book</span>, который содержит информацию о книге, например, название, автора, год издания и т.д. Определение <span style={{ fontWeight: 'bold' }}>Book</span> может выглядеть следующим образом:<br /><br />
              <div style={{ backgroundColor: "#6c58fd1a", padding: "10px" }}>
                Person [] myPerson;
              </div><br />
              &nbsp;&nbsp;В представленном коде объявлено отображение &#123;array&#125; с именем <span style={{ fontWeight: 'bold' }}>myPerson</span>, который изменяет или извлекает значения полей при помощи индексации массива.<br />
              &nbsp;&nbsp;Обратите внимание, что индексация в массивах начинается с 0
            </>}
          </div>}

          {modal_click === "Добавить функцию" && <div>
            {color === "write" && <button style={{ float: "right" }} className="text" data-tooltip-id="my-tooltiptwo" data-tooltip-content="Справка" onClick={() => { setHelp(help === "Функция" ? '' : 'Функция') }}><img src={help === "Функция" ? book_active : book} /></button>}
            {color === "black" && <button style={{ float: "right" }} className="text" data-tooltip-id="my-tooltiptwo" data-tooltip-content="Справка" onClick={() => { setHelp(help === "Функция" ? '' : 'Функция') }}><img src={help === "Функция" ? book_active : book_black} width="25" alt="" /></button>}<br /><br />
            <div className="block" data-tooltip-id="my-tooltiptwo" data-tooltip-content="Функция, Привет, мир!" onClick={() => { setModalActive(false); saveF('function output() public pure returns (string memory) {\n  return("Hello, world!");\n}', 'output') }}>
              function output() public pure returns (string memory) &#123; <br />
              &nbsp;&nbsp;return("Hello, world!");<br />
              &#125;
            </div><br />
            <div className="block" data-tooltip-id="my-tooltiptwo" data-tooltip-content="Функция, использующая ввод и вывод" onClick={() => { setModalActive(false); saveF('function output_text(string memory text) public pure returns (string memory) {\n  return(text);\n}', 'output_text') }}>
              function output_text(string memory text) public pure returns (string memory) &#123; <br />
              &nbsp;&nbsp;return(text);<br />
              &#125;
            </div><br />
            <div className="block" data-tooltip-id="my-tooltiptwo" data-tooltip-content="Функция, использующая условия с числами" onClick={() => { setModalActive(false); saveF('function isGreaterThan10(uint num) public pure returns (bool) {\n  if(num > 10) {\n    return true;\n  } else {\n  return false;\n  }\n}', 'isGreaterThan10') }}>
              function isGreaterThan10(uint num) public pure returns (bool) &#123; <br />
              &nbsp;&nbsp;if(num &gt; 10) &#123; <br />
              &nbsp;&nbsp;&nbsp;&nbsp;return true; <br />
              &nbsp;&nbsp;&#125; else &#123; <br />
              &nbsp;&nbsp;return false; <br />
              &nbsp;&nbsp;&#125; <br />
              &#125;
            </div><br />
            <div className="block" data-tooltip-id="my-tooltiptwo" data-tooltip-content="Функция, использующая условия с текстом" onClick={() => { setModalActive(false); saveF('function compareStrings(string memory str1, string memory str2) public pure returns (bool) {\n  return(keccak256(bytes(str1)) == keccak256(bytes(str2)));\n}', 'compareStrings') }}>
              function compareStrings(string memory str1, string memory str2) public pure returns (bool) &#123; <br />
              &nbsp;&nbsp;return(keccak256(bytes(str1)) == keccak256(bytes(str2)));<br />
              &#125;
            </div><br />
            <div className="block" data-tooltip-id="my-tooltiptwo" data-tooltip-content="Функция, использующая цикл" onClick={() => { setModalActive(false); saveF('function sum(uint number, string memory word) public pure returns (string memory) {\n  string memory text = "";\n  for (uint i = 0; i < number; i++) {\n    text = string(abi.encodePacked(text, word, " "));\n  }\n  return text;\n}', 'sum') }}>
              function sum(uint number, string memory word) public pure returns (string memory) &#123; <br />
              &nbsp;&nbsp;string memory text = "";<br />
              &nbsp;&nbsp;for (uint i = 0; i &lt; number; i++) &#123; <br />
              &nbsp;&nbsp;&nbsp;&nbsp;text = string(abi.encodePacked(text, word, " "));
              &#125;<br />
              &nbsp;&nbsp;return text;
              &#125;
            </div><br />
            <div className="block" data-tooltip-id="my-tooltiptwo" data-tooltip-content="Функция, использующая массив в памяти" onClick={() => { setModalActive(false); saveF('function addNumber(uint number, string memory word) public pure returns (string [] memory) {\n  string[] memory text = new string[](number);\n  for (uint i = 0; i < number; i++) {\n    text[i] = word;\n  }\n  return text;\n}', 'addNumber') }}>
              function addNumber(uint number, string memory word) public pure returns (string [] memory) &#123; <br />
              &nbsp;&nbsp;string[] memory text = new string[](number); <br />
              &nbsp;&nbsp;for (uint i = 0; i &lt; number; i++) &#123; <br />
              &nbsp;&nbsp;&nbsp;&nbsp;text[i] = word; <br />
              &nbsp;&nbsp;&#125; <br />
              &nbsp;&nbsp;return text;
              &#125;
            </div><br />
            <div className="block" data-tooltip-id="my-tooltiptwo" data-tooltip-content="Функция, использующая динамический массив" onClick={() => { setModalActive(false); saveF('uint[] public numbers;\n\nfunction addNumber_two(uint num) public {\n  for (uint i = 0; i < num; i++) {\n    numbers.push(i);\n  }\n}', 'addNumber_two') }}>
              uint[] public numbers;<br /><br />
              function addNumber_two(uint num) public &#123; <br />
              &nbsp;&nbsp;for (uint i = 0; i &lt; num; i++) &#123; <br />
              &nbsp;&nbsp;&nbsp;&nbsp;numbers.push(i);<br />
              &nbsp;&nbsp;&#125; <br />
              &#125;
            </div><br />
            {help === "Функция" && <><br />
              &nbsp;&nbsp;Функции в Solidity позволяют определять поведение контракта. Они могут изменять данные контракта или выполнять другие операции. Вот несколько примеров функций:<br /><br />
              <span style={{ fontWeight: 'bold' }}>Внешние функции</span>: Функции, которые могут быть вызваны извне контракта.<br /><br />
              <div style={{ backgroundColor: "#6c58fd1a", padding: "10px" }}>
                function setName(string memory _name) public &#123;<br />
                name = _name;<br />
                &#125;
              </div><br />
              &nbsp;&nbsp;<span style={{ fontWeight: 'bold' }}>Внутренние функции</span>: Функции, которые могут быть вызваны только из контракта или его наследников.<br />
              &nbsp;&nbsp;<div style={{ backgroundColor: "#6c58fd1a", padding: "10px" }}>
                function setName(string memory _name) public &#123;<br />
                name = _name;<br />
                &#125;
              </div><br />
              &nbsp;&nbsp;В Solidity функции имеют различные модификаторы, которые определяют их поведение в отношении чтения и изменения состояния контракта. Вот некоторые распространенные модификаторы функций в Solidity:<br /><br />
              &nbsp;&nbsp;<span style={{ fontWeight: 'bold' }}>pure</span>: Функция, помеченная модификатором pure, не имеет доступа к состоянию контракта и не изменяет его. Она выполняет только вычисления на основе входных параметров и возвращает значение. Пример:<br /><br />
              <div style={{ backgroundColor: "#6c58fd1a", padding: "10px" }}>
                function add(uint a, uint b) public pure returns (uint) &#123;<br />
                &nbsp;&nbsp;return a + b;<br />
                &#125;
              </div><br />
              &nbsp;&nbsp;<span style={{ fontWeight: 'bold' }}>view</span>: Функция, помеченная модификатором view, не изменяет состояние контракта, но может получать доступ к нему для чтения. Она возвращает значение, но не изменяет состояние контракта. Пример:<br /><br />
              <div style={{ backgroundColor: "#6c58fd1a", padding: "10px" }}>
                function add(uint a, uint b) public pure returns (uint) &#123;<br />
                &nbsp;&nbsp;return a + b;<br />
                &#125;
              </div><br />
              &nbsp;&nbsp;<span style={{ fontWeight: 'bold' }}>payable</span>: Функция, помеченная модификатором payable, может принимать эфирные платежи. Это позволяет другим аккаунтам отправлять эфир в контракт. Пример:<br /><br />
              <div style={{ backgroundColor: "#6c58fd1a", padding: "10px" }}>
                function deposit() public payable &#123;<br />
                &nbsp;&nbsp;// Логика для приема эфирного платежа<br />
                &#125;
              </div><br />
              &nbsp;&nbsp;<span style={{ fontWeight: 'bold' }}>public</span>: Модификатор public позволяет функции быть вызванной из внутренней части контракта и извне.<br /><br />
              &nbsp;&nbsp;<span style={{ fontWeight: 'bold' }}>private</span>: Модификатор private ограничивает видимость функции только внутри контракта.<br /><br />
              &nbsp;&nbsp;<span style={{ fontWeight: 'bold' }}>internal</span>: Модификатор internal делает функцию видимой только внутри контракта и его производных контрактов.<br /><br />
              &nbsp;&nbsp;<span style={{ fontWeight: 'bold' }}>external</span>: Модификатор external указывает, что функция может быть вызвана только извне контракта.<br /><br />
              &nbsp;&nbsp;Пример использования различных модификаторов:<br /><br />
              <div style={{ backgroundColor: "#6c58fd1a", padding: "10px" }}>
                uint public myNumber;<br /><br />
                function doSomething(uint a, uint b) public pure returns (uint) &#123;<br />
                &nbsp;&nbsp;return a + b;<br />
                &#125;<br /><br />
                function getMyNumber() public view returns (uint) &#123;<br />
                &nbsp;&nbsp;return myNumber;<br />
                &#125;<br /><br />
                function setMyNumber(uint newValue) private &#123;<br />
                &nbsp;&nbsp;myNumber = newValue;<br />
                &#125;<br /><br />
                function deposit() public payable &#123;<br />
                &nbsp;&nbsp;// Логика для приема эфирного платежа<br />
                &#125;<br />
              </div><br />
            </>}
          </div>}

          {modal_click === "Справка" && <div>
            <li className={"text_radio_" + color} onClick={() => { handleClick(0); setHelp("Контракт") }} style={{ color: activeIndex === 0 ? '#6d5bfd' : '' }}>Контракт</li><br />
            <li className={"text_radio_" + color} onClick={() => { handleClick(1); setHelp("Типы переменных") }} style={{ color: activeIndex === 1 ? '#6d5bfd' : '' }}>Типы переменных</li><br />
            <li className={"text_radio_" + color} onClick={() => { handleClick(2); setHelp("Глобальная переменная") }} style={{ color: activeIndex === 2 ? '#6d5bfd' : '' }}>Глобальная переменная</li><br />
            <li className={"text_radio_" + color} onClick={() => { handleClick(3); setHelp("Операторы") }} style={{ color: activeIndex === 3 ? '#6d5bfd' : '' }}>Операторы</li><br />
            <li className={"text_radio_" + color} onClick={() => { handleClick(4); setHelp("Массив") }} style={{ color: activeIndex === 4 ? '#6d5bfd' : '' }}>Массив</li><br />
            <li className={"text_radio_" + color} onClick={() => { handleClick(5); setHelp("Структура") }} style={{ color: activeIndex === 5 ? '#6d5bfd' : '' }}>Структура</li><br />
            <li className={"text_radio_" + color} onClick={() => { handleClick(6); setHelp("Конструктор") }} style={{ color: activeIndex === 6 ? '#6d5bfd' : '' }}>Конструктор</li><br />
            <li className={"text_radio_" + color} onClick={() => { handleClick(7); setHelp("Мадификатор") }} style={{ color: activeIndex === 7 ? '#6d5bfd' : '' }}>Мадификатор</li><br />
            <li className={"text_radio_" + color} onClick={() => { handleClick(8); setHelp("Функция") }} style={{ color: activeIndex === 8 ? '#6d5bfd' : '' }}>Функция</li><br />
            <li className={"text_radio_" + color} onClick={() => { handleClick(9); setHelp("Циклы") }} style={{ color: activeIndex === 9 ? '#6d5bfd' : '' }}>Циклы</li><br />
            <li className={"text_radio_" + color} onClick={() => { handleClick(10); setHelp("Условие") }} style={{ color: activeIndex === 10 ? '#6d5bfd' : '' }}>Условие</li><br /><br />

            {help === "Контракт" && <>
              &nbsp;&nbsp;Контракт - основной строительный блок в Solidity. Он содержит переменные, функции и другие элементы кода. Вот пример простого контракта:<br /><br />
              <div style={{ backgroundColor: "#6c58fd1a", padding: "10px" }}>
                contract MyContract &#123;<br />
                &nbsp;&nbsp;// Переменные и другие элементы кода<br />
                &nbsp;&nbsp;// ...<br />
                &#125;
              </div><br />
              &nbsp;&nbsp;Название для контракта в Solidity является идентификатором, используемым для идентификации и обращения к контракту в коде. Правильный выбор имени контракта может повысить читаемость и понимание кода другими разработчиками. Вот некоторые рекомендации и соглашения относительно названий контрактов:<br /><br />
              &nbsp;&nbsp;1. Имена контрактов должны быть описательными: Используйте имена, которые ясно описывают функциональность и назначение контракта. Это поможет другим разработчикам легче понять, что делает контракт. Например, если контракт представляет смарт-контракт для голосования, вы можете назвать его VotingContract.<br /><br />
              &nbsp;&nbsp;2. Соглашение об именовании: Хорошей практикой является использование соглашений об именовании, таких как CamelCase или PascalCase. Например, VotingContract или TokenSale.<br /><br />
              &nbsp;&nbsp;3. Избегайте односимвольных имен: Старайтесь избегать использования односимвольных имен, так как они могут быть непонятными и затруднять чтение и понимание кода.<br /><br />
              &nbsp;&nbsp;4. Избегайте конфликтов имен: Убедитесь, что имя контракта не конфликтует с уже существующими именами контрактов или ключевыми словами в Solidity.<br /><br />
              &nbsp;&nbsp;5. Используйте понятные имена переменных и функций: Помимо названия контракта, также важно использовать понятные имена для переменных и функций внутри контракта. Это сделает код более читаемым и понятным.<br /><br />
            </>}
            {help === "Типы переменных" && <>
              &nbsp;&nbsp;Solidity поддерживает различные типы данных для определения переменных. Некоторые из наиболее распространенных типов данных в Solidity включают:<br /><br />
              &nbsp;&nbsp;<span style={{ fontWeight: 'bold' }}>bool</span>: Логический тип данных, который может быть либо true (истина), либо false (ложь).<br /><br />
              <div style={{ backgroundColor: "#6c58fd1a", padding: "10px" }}>
                bool isTrue = true;<br />
                bool isFalse = false;
              </div><br />
              &nbsp;&nbsp;<span style={{ fontWeight: 'bold' }}>uint</span>: Беззнаковое целое число, которое может быть положительным или нулем.<br /><br />
              <div style={{ backgroundColor: "#6c58fd1a", padding: "10px" }}>
                uint number = 42;
              </div><br />
              &nbsp;&nbsp;<span style={{ fontWeight: 'bold' }}>int</span>: Знаковое целое число, которое может быть положительным, нулем или отрицательным.<br /><br />
              <div style={{ backgroundColor: "#6c58fd1a", padding: "10px" }}>
                int balance = -100;
              </div><br />
              &nbsp;&nbsp;<span style={{ fontWeight: 'bold' }}>address</span>: Тип данных, предназначенный для хранения адресов Ethereum.<br /><br />
              <div style={{ backgroundColor: "#6c58fd1a", padding: "10px" }}>
                address owner = msg.sender;
              </div><br />
              &nbsp;&nbsp;<span style={{ fontWeight: 'bold' }}>string</span>: Строковый тип данных для хранения текстовых значений.<br /><br />
              <div style={{ backgroundColor: "#6c58fd1a", padding: "10px" }}>
                string name = "Alice";
              </div><br />
              &nbsp;&nbsp;<span style={{ fontWeight: 'bold' }}>mapping</span>: Хеш-таблица, которая связывает ключи с значениями.<br /><br />
              <div style={{ backgroundColor: "#6c58fd1a", padding: "10px" }}>
                mapping(address =&gt; uint) public balances;
              </div><br />
            </>}
            {help === "Глобальная переменная" && <>
              &nbsp;&nbsp;Solidity предоставляет несколько глобальных переменных, которые могут быть использованы в контрактах:<br /><br />
              &nbsp;&nbsp;Ключевое слово <span style={{ fontWeight: 'bold' }}>public</span> в контексте глобальной переменной в Solidity означает, что значение этой переменной будет доступно для чтения извне контракта.<br /><br />
              &nbsp;&nbsp;Когда вы объявляете переменную как public, Solidity автоматически создает геттер-функцию для этой переменной, которая позволяет другим контрактам или внешним аккаунтам читать значение этой переменной.<br /><br />
              <div style={{ backgroundColor: "#6c58fd1a", padding: "10px" }}>
                uint[] public numbers;
              </div><br />
              <span style={{ fontWeight: 'bold' }}>msg.sender</span>: Адрес отправителя текущей транзакции.<br /><br />
              <div style={{ backgroundColor: "#6c58fd1a", padding: "10px" }}>
                address sender = msg.sender;
              </div><br />
              <span style={{ fontWeight: 'bold' }}>msg.value</span>: Количество Ether, отправленное с транзакцией.<br /><br />
              <div style={{ backgroundColor: "#6c58fd1a", padding: "10px" }}>
                uint value = msg.value;
              </div><br />
            </>}
            {help === "Операторы" && <>
              &nbsp;&nbsp;Solidity поддерживает широкий набор операторов для выполнения различных операций. Некоторые из наиболее распространенных операторов:<br /><br />
              &nbsp;&nbsp;<span style={{ fontWeight: 'bold' }}>Логический оператор И (&&)</span>:<br />
              &nbsp;&nbsp;Логический оператор И возвращает true, если оба операнда являются истинными, и false в противном случае. Например:<br /><br />
              <div style={{ backgroundColor: "#6c58fd1a", padding: "10px" }}>
                bool a = true;<br />
                bool b = false;<br />
                bool result = a && b; // result будет равно false
              </div><br />
              &nbsp;&nbsp;<span style={{ fontWeight: 'bold' }}>Логический оператор ИЛИ (||)</span>:<br /><br />
              &nbsp;&nbsp;Логический оператор ИЛИ возвращает true, если хотя бы один из операндов является истинным, и false, если оба операнда ложные. Например:<br /><br />
              <div style={{ backgroundColor: "#6c58fd1a", padding: "10px" }}>
                bool a = true;<br />
                bool b = false;<br />
                bool result = a || b; // result будет равно true
              </div><br />
              &nbsp;&nbsp;<span style={{ fontWeight: 'bold' }}>Логический оператор НЕ (!)</span>:<br /><br />
              &nbsp;&nbsp;Логический оператор НЕ инвертирует значение операнда. Если операнд равен true, оператор возвращает false, и наоборот. Например:<br /><br />
              <div style={{ backgroundColor: "#6c58fd1a", padding: "10px" }}>
                bool a = true;<br />
                bool result = !a; // result будет равно false
              </div><br />
              &nbsp;&nbsp;<span style={{ fontWeight: 'bold' }}>Арифметические операторы</span>: + (сложение), - (вычитание), * (умножение), / (деление) и т.д.<br /><br />
              &nbsp;&nbsp;<span style={{ fontWeight: 'bold' }}>Операторы сравнения</span>: == (равно), != (не равно),  &gt; (больше),  &lt; (меньше),  &gt;= (больше или равно),  &lt;= (меньше или равно) и т.д.<br /><br />
              <div style={{ backgroundColor: "#6c58fd1a", padding: "10px" }}>
                uint256 a = 10;<br />
                uint256 b = 5;<br />
                uint256 c = a + b; // c будет равно 15<br />
                bool isEqual = (a == b); // isEqual будет равно false
              </div>
            </>}
            {help === "Функция" && <>
              &nbsp;&nbsp;Функции в Solidity позволяют определять поведение контракта. Они могут изменять данные контракта или выполнять другие операции. Вот несколько примеров функций:<br /><br />
              <span style={{ fontWeight: 'bold' }}>Внешние функции</span>: Функции, которые могут быть вызваны извне контракта.<br /><br />
              <div style={{ backgroundColor: "#6c58fd1a", padding: "10px" }}>
                function setName(string memory _name) public &#123;<br />
                name = _name;<br />
                &#125;
              </div><br />
              &nbsp;&nbsp;<span style={{ fontWeight: 'bold' }}>Внутренние функции</span>: Функции, которые могут быть вызваны только из контракта или его наследников.<br />
              &nbsp;&nbsp;<div style={{ backgroundColor: "#6c58fd1a", padding: "10px" }}>
                function setName(string memory _name) public &#123;<br />
                name = _name;<br />
                &#125;
              </div><br />
              &nbsp;&nbsp;В Solidity функции имеют различные модификаторы, которые определяют их поведение в отношении чтения и изменения состояния контракта. Вот некоторые распространенные модификаторы функций в Solidity:<br /><br />
              &nbsp;&nbsp;<span style={{ fontWeight: 'bold' }}>pure</span>: Функция, помеченная модификатором pure, не имеет доступа к состоянию контракта и не изменяет его. Она выполняет только вычисления на основе входных параметров и возвращает значение. Пример:<br /><br />
              <div style={{ backgroundColor: "#6c58fd1a", padding: "10px" }}>
                function add(uint a, uint b) public pure returns (uint) &#123;<br />
                &nbsp;&nbsp;return a + b;<br />
                &#125;
              </div><br />
              &nbsp;&nbsp;<span style={{ fontWeight: 'bold' }}>view</span>: Функция, помеченная модификатором view, не изменяет состояние контракта, но может получать доступ к нему для чтения. Она возвращает значение, но не изменяет состояние контракта. Пример:<br /><br />
              <div style={{ backgroundColor: "#6c58fd1a", padding: "10px" }}>
                function add(uint a, uint b) public pure returns (uint) &#123;<br />
                &nbsp;&nbsp;return a + b;<br />
                &#125;
              </div><br />
              &nbsp;&nbsp;<span style={{ fontWeight: 'bold' }}>payable</span>: Функция, помеченная модификатором payable, может принимать эфирные платежи. Это позволяет другим аккаунтам отправлять эфир в контракт. Пример:<br /><br />
              <div style={{ backgroundColor: "#6c58fd1a", padding: "10px" }}>
                function deposit() public payable &#123;<br />
                &nbsp;&nbsp;// Логика для приема эфирного платежа<br />
                &#125;
              </div><br />
              &nbsp;&nbsp;<span style={{ fontWeight: 'bold' }}>public</span>: Модификатор public позволяет функции быть вызванной из внутренней части контракта и извне.<br /><br />
              &nbsp;&nbsp;<span style={{ fontWeight: 'bold' }}>private</span>: Модификатор private ограничивает видимость функции только внутри контракта.<br /><br />
              &nbsp;&nbsp;<span style={{ fontWeight: 'bold' }}>internal</span>: Модификатор internal делает функцию видимой только внутри контракта и его производных контрактов.<br /><br />
              &nbsp;&nbsp;<span style={{ fontWeight: 'bold' }}>external</span>: Модификатор external указывает, что функция может быть вызвана только извне контракта.<br /><br />
              &nbsp;&nbsp;Пример использования различных модификаторов:<br /><br />
              <div style={{ backgroundColor: "#6c58fd1a", padding: "10px" }}>
                uint public myNumber;<br /><br />
                function doSomething(uint a, uint b) public pure returns (uint) &#123;<br />
                &nbsp;&nbsp;return a + b;<br />
                &#125;<br /><br />
                function getMyNumber() public view returns (uint) &#123;<br />
                &nbsp;&nbsp;return myNumber;<br />
                &#125;<br /><br />
                function setMyNumber(uint newValue) private &#123;<br />
                &nbsp;&nbsp;myNumber = newValue;<br />
                &#125;<br /><br />
                function deposit() public payable &#123;<br />
                &nbsp;&nbsp;// Логика для приема эфирного платежа<br />
                &#125;<br />
              </div><br />
            </>}
            {help === "Массив" && <>
              &nbsp;&nbsp;Массивы позволяют хранить наборы элементов одного типа. Вот пример объявления и использования массива:<br /><br />
              <div style={{ backgroundColor: "#6c58fd1a", padding: "10px" }}>
                uint[] public myArray; // объявление динамического массива<br />
                string[5] public myFixedArray; // объявление фиксированного массива размером 5<br />
                <br />
                function addToMyArray(uint _value) public &#123;<br />
                &nbsp;&nbsp;myArray.push(_value); // добавление элемента в динамический массив<br />
                &#125;<br />
                <br />
                function getFixedArrayLength() public view returns (uint) &#123;<br />
                &nbsp;&nbsp;return myFixedArray.length; // получение длины фиксированного массива<br />
                &#125;<br /><br />
                function addNumber(uint number, string memory word) public pure returns (string [] memory) &#123; <br />
                &nbsp;&nbsp;string[] memory text = new string[](number); <br />
                &nbsp;&nbsp;for (uint i = 0; i &lt; number; i++) &#123; <br />
                &nbsp;&nbsp;&nbsp;&nbsp;text[i] = word; <br />
                &nbsp;&nbsp;&#125; <br />
                &nbsp;&nbsp;return text;
                &#125;
              </div><br />
            </>}
            {help === "Структура" && <>
              &nbsp;&nbsp;Solidity позволяет определять пользовательские структуры, которые могут содержать несколько полей с различными типами данных. Структуры полезны для создания более сложных объектов данных.<br /><br />
              <div style={{ backgroundColor: "#6c58fd1a", padding: "10px" }}>
                struct Person &#123;<br />
                &nbsp;&nbsp;string name;<br />
                &nbsp;&nbsp;uint age;<br />
                &#125;<br />
                Person [] myPerson;<br /><br />
                struct Book &#123;<br />
                &nbsp;&nbsp;string name;<br />
                &#125;<br />
                mapping(uint =&gt; Book) Books;<br /><br /><br />
                function fillStructures() public &#123;<br />
                &nbsp;&nbsp;// Заполнение структуры Person<br />
                &nbsp;&nbsp;myPerson.push(Person("Alice", 25));<br />
                &nbsp;&nbsp;myPerson.push(Person("Bob", 30));<br /><br />
                &nbsp;&nbsp;// Заполнение структуры Book<br />
                &nbsp;&nbsp;Books[1] = Book("Book 1");<br />
                &nbsp;&nbsp;Books[2] = Book("Book 2");<br />
                &#125;
              </div>
            </>}
            {help === "Конструктор" && <>
              &nbsp;&nbsp;Конструктор - это специальная функция, которая выполняется при создании экземпляра контракта. Конструктор имеет то же имя, что и контракт, и выполняет инициализацию переменных и других состояний контракта. Вот пример конструктора:<br /><br />
              <div style={{ backgroundColor: "#6c58fd1a", padding: "10px" }}>
                contract MyContract &#123;<br />
                &nbsp;&nbsp;uint public myVariable;<br />
                <br />
                &nbsp;&nbsp;constructor() &#123;<br />
                &nbsp;&nbsp;&nbsp;&nbsp;myVariable = 10; // инициализация переменной при создании контракта<br />
                &nbsp;&nbsp;&#125;<br />
                &#125;
              </div>
            </>}
            {help === "Мадификатор" && <>
              &nbsp;&nbsp;Модификаторы в Solidity — это фрагменты кода, которые позволяют изменять поведение функций, обычно добавляя предварительные или последующие проверки, условия или логику. Они используются для упрощения и повторного использования кода, а также для обеспечения безопасности и согласованности в смарт-контрактах.<br /><br />
              &nbsp;&nbsp;Модификаторы определяются с помощью ключевого слова modifier и имеют свое собственное имя. Они могут быть применены к функциям в Solidity для изменения их поведения. Когда функция объявляется с применением модификатора, код модификатора выполняется перед выполнением самой функции.<br /><br />
              &nbsp;&nbsp;Вот пример использования модификатора:<br /><br />
              <div style={{ backgroundColor: "#6c58fd1a", padding: "10px" }}>
                bool public isReady;<br /><br />
                modifier whenReady() &#123;<br />
                &nbsp;&nbsp;require(isReady == true, "The contract is not ready yet.");<br />
                &nbsp;&nbsp;_; // Продолжение выполнения после модификатора<br />
                &#125;<br /><br />
                function doSomething() public whenReady &#123;<br />
                &nbsp;&nbsp;// Выполнение кода функции<br />
                &#125;
              </div><br />
              &nbsp;&nbsp;В этом примере определен модификатор whenReady, который проверяет, установлено ли значение переменной isReady в контракте равным true. Если проверка успешна, код функции doSomething выполняется. Если проверка не проходит, вызывается исключение require, и выполнение прерывается.<br /><br />
              &nbsp;&nbsp;Модификаторы могут быть настроены по вашему усмотрению и могут включать в себя различные проверки и условия, которые вы хотите применить перед выполнением функции.
            </>}
            {help === "Циклы" && <>
              &nbsp;&nbsp;В Solidity доступны несколько типов циклов, которые позволяют повторять определенные операции или блоки кода. Вот несколько примеров циклов в Solidity:<br /><br />
              &nbsp;&nbsp;Цикл <span style={{ fontWeight: 'bold' }}>for</span>: Цикл for используется для выполнения операций определенное количество раз. Пример:<br /><br />
              <div style={{ backgroundColor: "#6c58fd1a", padding: "10px" }}>
                function countToTen() public pure returns (uint) &#123;<br />
                &nbsp;&nbsp;uint sum = 0;<br />
                &nbsp;&nbsp;for (uint i = 1; i &lt;= 10; i++) &#123;<br />
                &nbsp;&nbsp;&nbsp;&nbsp;sum += i;<br />
                &nbsp;&nbsp;&#125;<br />
                &nbsp;&nbsp;return sum;<br />
                &#125;
              </div><br />
              &nbsp;&nbsp;В этом примере цикл for выполняется 10 раз и суммирует значения от 1 до 10.<br /><br />
              &nbsp;&nbsp;Цикл <span style={{ fontWeight: 'bold' }}>while</span>: Цикл while выполняется, пока условие истинно. Пример:<br /><br />
              <div style={{ backgroundColor: "#6c58fd1a", padding: "10px" }}>
                function countToTen() public pure returns (uint) &#123;<br />
                &nbsp;&nbsp;uint sum = 0;<br />
                &nbsp;&nbsp;uint i = 1;<br />
                &nbsp;&nbsp;while (i &lt;= 10) &#123;<br />
                &nbsp;&nbsp;&nbsp;&nbsp;sum += i;<br />
                &nbsp;&nbsp;&nbsp;&nbsp;i++;<br />
                &nbsp;&nbsp;&#125;<br />
                &nbsp;&nbsp;return sum;<br />
                &#125;
              </div><br />
              &nbsp;&nbsp;В этом примере цикл while выполняется до тех пор, пока значение i меньше или равно 10, и суммирует значения от 1 до 10.<br /><br />
              &nbsp;&nbsp;Цикл <span style={{ fontWeight: 'bold' }}>do-while</span>: Цикл do-while похож на цикл while, но проверка условия выполняется после каждой итерации цикла. Пример:<br /><br />
              <div style={{ backgroundColor: "#6c58fd1a", padding: "10px" }}>
                function countToTen() public pure returns (uint) &#123;<br />
                &nbsp;&nbsp;uint sum = 0;<br />
                &nbsp;&nbsp;uint i = 1;<br />
                &nbsp;&nbsp;do &#123;<br />
                &nbsp;&nbsp;&nbsp;&nbsp;sum += i;<br />
                &nbsp;&nbsp;&nbsp;&nbsp;i++;<br />
                &nbsp;&nbsp;&#125; while (i &lt;= 10);<br />
                &nbsp;&nbsp;return sum;<br />
                &#125;
              </div><br />
              &nbsp;&nbsp;В этом примере цикл do-while выполняет блок кода хотя бы один раз и продолжает выполняться до тех пор, пока значение i меньше или равно 10, и суммирует значения от 1 до 10.<br /><br />
              &nbsp;&nbsp;Важно учитывать, что в Solidity операции с циклами могут быть ограничены из-за газовых ограничений, поэтому циклы должны быть проектированы таким образом, чтобы не превышать лимиты газа и не приводить к зацикливанию.<br /><br />
            </>}
            {help === "Условие" && <>
              &nbsp;&nbsp;В Solidity условные выражения позволяют выполнять определенные блоки кода на основе условия или значений переменных. С помощью условных выражений можно реализовать логику ветвления в смарт-контрактах. Вот несколько примеров условных выражений в Solidity:<br /><br />
              &nbsp;&nbsp;Условие <span style={{ fontWeight: 'bold' }}>if</span>: Условие if выполняет блок кода, если условие истинно. Если условие ложно, то блок кода if пропускается. Пример:<br /><br />
              <div style={{ backgroundColor: "#6c58fd1a", padding: "10px" }}><br />
                function checkEven(uint number) public pure returns (string memory) &#123;<br />
                &nbsp;&nbsp;if (number % 2 == 0) &#123;<br />
                &nbsp;&nbsp;&nbsp;&nbsp;return "Number is even";<br />
                &nbsp;&nbsp;&#125; else &#123;<br />
                &nbsp;&nbsp;&nbsp;&nbsp;return "Number is odd";<br />
                &nbsp;&nbsp;&#125;<br />
                &#125;
              </div><br />
              &nbsp;&nbsp;В этом примере, если значение переменной number является четным числом, то будет возвращена строка "Number is even". В противном случае, будет возвращена строка "Number is odd".<br /><br />
              &nbsp;&nbsp;Условие <span style={{ fontWeight: 'bold' }}>if-else if-else</span>: Условие if-else if-else позволяет выполнить блок кода, соответствующий первому истинному условию из списка условий. Пример:
              <div style={{ backgroundColor: "#6c58fd1a", padding: "10px" }}><br />
                function checkGrade(uint score) public pure returns (string memory) &#123;<br />
                &nbsp;&nbsp;if (score &gt;= 90) &#123;<br />
                &nbsp;&nbsp;&nbsp;&nbsp;return "A";<br />
                &nbsp;&nbsp;&#125; else if (score &gt;= 80) &#123;<br />
                &nbsp;&nbsp;&nbsp;&nbsp;return "B";<br />
                &nbsp;&nbsp;&#125; else if (score &gt;= 70) &#123;<br />
                &nbsp;&nbsp;&nbsp;&nbsp;return "C";<br />
                &nbsp;&nbsp;&#125; else &#123;<br />
                &nbsp;&nbsp;&nbsp;&nbsp;return "D";<br />
                &nbsp;&nbsp;&#125;<br />
                &#125;
              </div><br />
              &nbsp;&nbsp;В этом примере, на основе значения переменной score возвращается оценка "A", "B", "C" или "D" в зависимости от диапазона, в котором находится значение.<br /><br />
              &nbsp;&nbsp;<span style={{ fontWeight: 'bold' }}>Тернарный оператор</span>: Тернарный оператор позволяет сократить запись условия в одну строку. Он имеет следующий синтаксис: условие ? значение_если_истина : значение_если_ложь. Пример:<br /><br />
              <div style={{ backgroundColor: "#6c58fd1a", padding: "10px" }}><br />
                function checkEven(uint number) public pure returns (string memory) &#123;<br />
                &nbsp;&nbsp;return number % 2 == 0 ? "Number is even" : "Number is odd";<br />
                &#125;
              </div><br />
              &nbsp;&nbsp;В этом примере используется тернарный оператор для сокращенной проверки четности числа.<br /><br />
              &nbsp;&nbsp;Условие сравнения текста в Solidity позволяет сравнивать строки на равенство.<br /><br />
              <div style={{ backgroundColor: "#6c58fd1a", padding: "10px" }}><br />
                function compareStrings(string memory a, string memory b) public pure returns (bool) &#123;<br />
                &nbsp;&nbsp;if (keccak256(bytes(a)) == keccak256(bytes(b))) &#123;<br />
                &nbsp;&nbsp;&nbsp;&nbsp;return true;<br />
                &nbsp;&nbsp;&#125; else &#123;<br />
                &nbsp;&nbsp;&nbsp;&nbsp;return false;<br />
                &nbsp;&nbsp;&#125;<br />
                &#125;
              </div><br />
              &nbsp;&nbsp;В этом примере функция compareStrings сравнивает две строки a и b на равенство. Оператор <span style={{ fontWeight: 'bold' }}>keccak256(bytes(a))</span> преобразует строку a в хеш-значение, которое затем сравнивается с хеш-значением строки b. Если строки идентичны, то возвращается значение true, в противном случае - false.<br /><br />
              &nbsp;&nbsp;Кроме оператора ==, можно использовать и другие операторы сравнения для строк. Например:<br /><br />
              <div style={{ backgroundColor: "#6c58fd1a", padding: "10px" }}><br />
                function compareStrings(string memory a, string memory b) public pure returns (bool) &#123;<br />
                &nbsp;&nbsp;if (bytes(a).length &lt; bytes(b).length) &#123;<br />
                &nbsp;&nbsp;&nbsp;&nbsp;return true;<br />
                &nbsp;&nbsp;&#125; else &#123;<br />
                &nbsp;&nbsp; &nbsp;&nbsp;return false;<br />
                &nbsp;&nbsp;&#125;<br />
                &#125;
              </div><br />
              &nbsp;&nbsp;В этом примере функция compareStrings сравнивает длину двух строк a и b. Если длина строки a меньше, чем длина строки b, то возвращается значение true, в противном случае - false.<br /><br />
            </>}
          </div>}

          {modal_click === "Главная_Справка" && <div >
            <li className={"text_radio_" + color} onClick={() => { handleClick(0); setHelp("Выход из личного кабинета") }} style={{ color: activeIndex === 0 ? '#6d5bfd' : '' }}>Выйти из личного кабинета</li><br />
            <li className={"text_radio_" + color} onClick={() => { handleClick(1); setHelp("Сменить тему") }} style={{ color: activeIndex === 1 ? '#6d5bfd' : '' }}>Сменить тему</li><br />
            Контракты:<div style={{ marginLeft: "9px" }}>
              <li className={"text_radio_" + color} onClick={() => { handleClick(2); setHelp("Создать контракт") }} style={{ color: activeIndex === 2 ? '#6d5bfd' : '' }}>Создать контракт</li><br />
              <li className={"text_radio_" + color} onClick={() => { handleClick(3); setHelp("Удалить контракт") }} style={{ color: activeIndex === 3 ? '#6d5bfd' : '' }}>Удалить контракт</li><br />
              <li className={"text_radio_" + color} onClick={() => { handleClick(4); setHelp("Скачать контракт") }} style={{ color: activeIndex === 4 ? '#6d5bfd' : '' }}>Скачать контракт</li><br />
              <li className={"text_radio_" + color} onClick={() => { handleClick(5); setHelp("Открыть контракт") }} style={{ color: activeIndex === 5 ? '#6d5bfd' : '' }}>Открыть контракт</li><br />
              <li className={"text_radio_" + color} onClick={() => { handleClick(6); setHelp("Добавить структуру") }} style={{ color: activeIndex === 6 ? '#6d5bfd' : '' }}>Добавить структуру</li><br />
              <li className={"text_radio_" + color} onClick={() => { handleClick(7); setHelp("Удалить структуру") }} style={{ color: activeIndex === 7 ? '#6d5bfd' : '' }}>Удалить структуру</li><br />
              <li className={"text_radio_" + color} onClick={() => { handleClick(8); setHelp("Добавить функцию") }} style={{ color: activeIndex === 8 ? '#6d5bfd' : '' }}>Добавить функцию</li><br />
              <li className={"text_radio_" + color} onClick={() => { handleClick(9); setHelp("Удалить функцию") }} style={{ color: activeIndex === 9 ? '#6d5bfd' : '' }}>Удалить функцию</li><br />
              <li className={"text_radio_" + color} onClick={() => { handleClick(10); setHelp("Копировать код контракта") }} style={{ color: activeIndex === 10 ? '#6d5bfd' : '' }}>Копировать код контракта</li><br />
              <li className={"text_radio_" + color} onClick={() => { handleClick(11); setHelp("Справка по коду контракта") }} style={{ color: activeIndex === 11 ? '#6d5bfd' : '' }}>Справка по коду контракта</li><br />
            </div>
            <br />
            {help === "Выход из личного кабинета" && <>
              Для выхода из личного кабинета выполните следующие действия: <br /><br />
              &nbsp;&nbsp;1. нажмите на иконку <span style={{ fontWeight: 'bold' }}>“Выйти из личного кабинета”</span>, изображенную на рисунке ниже, расположенную в правом верхнем углу. <br /><br />
              <center><img src={one} width="250" alt="" /></center>
            </>}
            {help === "Сменить тему" && <>
              Для изменения темы выполните следующие действия: <br /><br />
              &nbsp;&nbsp;1. нажмите на иконку <span style={{ fontWeight: 'bold' }}>“Сменить тему”</span>, изображенную на рисунке ниже, расположенную в правом верхнем углу. <br /><br />
              <center><img src={two} width="250" alt="" /></center>
            </>}
            {help === "Создать контракт" && <>
              Для создания контракта следуйте следующим инструкциям: <br /><br />
              &nbsp;&nbsp;1. перейдите во вкладку <span style={{ fontWeight: 'bold' }}>"Контракты"</span> на левой панели, как показано на рисунке ниже; <br /><br />
              <center><img src={three} width="400" alt="" /></center><br />
              &nbsp;&nbsp;2. Нажмите на иконку <span style={{ fontWeight: 'bold' }}>"Создать контракт"</span>, которую мы можем увидеть на рисунке, предоставленном ниже; <br /><br />
              <center><img src={four} width="400" alt="" /></center><br />
              &nbsp;&nbsp;3. После этого откроется поле ввода, как показано на следующем рисунке. Введите название контракта в это поле; <br /><br />
              <center><img src={five} width="400" alt="" /></center><br />
              &nbsp;&nbsp;4. После ввода названия контракта нажмите кнопку <span style={{ fontWeight: 'bold' }}>"Enter"</span> на клавиатуре. В результате будет создан контракт, который можно увидеть на предоставленном ниже рисунке. <br /><br />
              <center><img src={six} width="400" alt="" /></center>
            </>}
            {help === "Удалить контракт" && <>
              Для удаления контракта выполните следующие действия: <br /><br />
              &nbsp;&nbsp;1. Перейдите во вкладку <span style={{ fontWeight: 'bold' }}>"Контракты"</span> на левой панели, как показано на рисунке ниже; <br /><br />
              <center><img src={three} width="400" alt="" /></center><br />
              &nbsp;&nbsp;2. Щелкните правой кнопкой мыши на контракте, который вы хотите удалить. В данном примере мы удаляем контракт с названием <span style={{ fontWeight: 'bold' }}>"two"</span>, как показано на предоставленном ниже изображении; <br /><br />
              <center><img src={seven} width="400" alt="" /></center><br />
              &nbsp;&nbsp;3. Появится контекстное меню, где вы будете представлены выбором между <span style={{ fontWeight: 'bold' }}>"Удалить контракт"</span> и <span style={{ fontWeight: 'bold' }}>"Скачать"</span>. Это показано на следующем изображении; <br /><br />
              <center><img src={eight} width="400" alt="" /></center><br />
              &nbsp;&nbsp;4. Выберите опцию <span style={{ fontWeight: 'bold' }}>"Удалить"</span>, щелкнув на ней левой кнопкой мыши. В результате контракт будет удален, как показано на следующем изображении. <br /><br />
              <center><img src={nine} width="400" alt="" /></center>
            </>}
            {help === "Скачать контракт" && <>
              Для скачивания контракта выполните следующие действия: <br /><br />
              &nbsp;&nbsp;1. Перейдите во вкладку <span style={{ fontWeight: 'bold' }}>"Контракты"</span> на левой панели, как показано на рисунке ниже; <br /><br />
              <center><img src={three} width="400" alt="" /></center><br />
              &nbsp;&nbsp;2. Щелкните правой кнопкой мыши на контракте, который вы хотите скачать. В данном примере мы скачиваем контракт с названием <span style={{ fontWeight: 'bold' }}>"one"</span>, как показано на предоставленном ниже изображении; <br /><br />
              <center><img src={ten} width="400" alt="" /></center><br />
              &nbsp;&nbsp;3. Появится контекстное меню, где вы будете представлены выбором между <span style={{ fontWeight: 'bold' }}>"Удалить контракт"</span> и <span style={{ fontWeight: 'bold' }}>"Скачать"</span>. Это показано на следующем изображении; <br /><br />
              <center><img src={eleven} width="400" alt="" /></center><br />
              &nbsp;&nbsp;4. Выберите опцию <span style={{ fontWeight: 'bold' }}>"Скачать"</span>, щелкнув на ней левой кнопкой мыши. В результате контракт будет скачен. <br /><br />
            </>}
            {help === "Открыть контракт" && <>
              Для того чтобы открыть контракт выполните следующие действия: <br /><br />
              &nbsp;&nbsp;1. Перейдите во вкладку <span style={{ fontWeight: 'bold' }}>"Контракты"</span> на левой панели, как показано на рисунке ниже; <br /><br />
              <center><img src={three} width="400" alt="" /></center><br />
              &nbsp;&nbsp;2. нажмите на иконку <span style={{ fontWeight: 'bold' }}>“Открыть контракт”</span>, изображенную на рисунке ниже. В результате контракт будет открыт.  <br /><br />
              <center><img src={twelve} width="400" alt="" /></center>
            </>}
            {help === "Добавить структуру" && <>
              Для того чтобы добавить структуру выполните следующие действия:<br /><br />
              &nbsp;&nbsp;1. Перейдите во вкладку <span style={{ fontWeight: 'bold' }}>"Контракты"</span> на левой панели, как показано на рисунке ниже;<br /><br />
              <center><img src={three} width="400" alt="" /></center><br />
              &nbsp;&nbsp;2. нажмите на иконку <span style={{ fontWeight: 'bold' }}>“Открыть контракт”</span>, изображенную на рисунке ниже;<br /><br />
              <center><img src={twelve} width="400" alt="" /></center><br />
              &nbsp;&nbsp;3. На правой панели найдите иконку <span style={{ fontWeight: 'bold' }}>"Добавить структуру"</span>, как показано на рисунке ниже, и щелкните на нее;<br /><br />
              <center><img src={thirteen} width="200" alt="" /></center><br />
              &nbsp;&nbsp;4. В результате откроется модальное окно с активным полем ввода <span style={{ fontWeight: 'bold' }}>"Название структуры"</span>, как показано на рисунке ниже. Введите название структуры в это поле;<br /><br />
              <center><img src={seventeen} width="400" alt="" /></center><br />
              &nbsp;&nbsp;5. После ввода названия структуры нажмите на иконку <span style={{ fontWeight: 'bold' }}>"Добавить переменную"</span>, которую можно увидеть на предоставленном ниже рисунке;<br /><br />
              <center><img src={eighteen} width="400" alt="" /></center><br />
              &nbsp;&nbsp;6. Далее появятся два поля ввода: <span style={{ fontWeight: 'bold' }}>"Название переменной"</span> и <span style={{ fontWeight: 'bold' }}>"Тип переменной"</span>, как показано на изображении ниже. Заполните эти поля.<br /><br />
              <center><img src={nineteen} width="400" alt="" /></center><br />
              &nbsp;&nbsp;7. После заполнения полей структуры нажмите на иконку <span style={{ fontWeight: 'bold' }}>"Добавить"</span>, которую можно увидеть на предоставленном ниже рисунке;<br /><br />
              <center><img src={twenty} width="400" alt="" /></center><br />
              &nbsp;&nbsp;8. После этого у вас будет выбор: удалить переменную, добавить переменную или выбрать способы хранения и организации данных в структуре, как показано на рисунках ниже;<br /><br />
              <center><img src={twenty_one} width="400" alt="" /></center><br />
              <center><img src={twenty_two} width="400" alt="" /></center><br />
              <center><img src={twenty_three} width="400" alt="" /></center><br />
              &nbsp;&nbsp;9. Чтобы выбрать способ хранения и организации данных в структуре, нажмите на ячейку <span style={{ fontWeight: 'bold' }}>"Тип структуры – отображения"</span>. После этого вы сможете выбрать ключ-значения для отображения, как показано на изображении ниже;<br /><br />
              <center><img src={twenty_four} width="400" alt="" /></center><br />
              &nbsp;&nbsp;10. Затем выберите тип ключа значения для отображения, после чего появится кнопка <span style={{ fontWeight: 'bold' }}>"Добавить структуру"</span>, как показано на изображении ниже. Нажмите на эту кнопку, чтобы добавить созданную вами структуру в код;<br /><br />
              <center><img src={twenty_five} width="400" alt="" /></center><br />
              <center><img src={twenty_six} width="350" alt="" /></center>
            </>}
            {help === "Добавить функцию" && <>
              Для того чтобы добавить функцию выполните следующие действия:<br /><br />
              &nbsp;&nbsp;1. Перейдите во вкладку <span style={{ fontWeight: 'bold' }}>"Контракты"</span> на левой панели, как показано на рисунке ниже;<br /><br />
              <center><img src={three} width="400" alt="" /></center><br />
              &nbsp;&nbsp;2. нажмите на иконку <span style={{ fontWeight: 'bold' }}>“Открыть контракт”</span>, изображенную на рисунке ниже;<br /><br />
              <center><img src={twelve} width="400" alt="" /></center><br />
              &nbsp;&nbsp;3. На правой панели найдите иконку <span style={{ fontWeight: 'bold' }}>"Добавить функцию"</span>, как показано на рисунке ниже, и щелкните на нее;<br /><br />
              <center><img src={fourteen} width="200" alt="" /></center><br />
              &nbsp;&nbsp;4. В результате откроется модальное окно с доступными функциями как показано на изображении ниже. Нажмите на выбранную функцию, чтобы добавить её в код.<br /><br />
              <center><img src={twenty_seven} width="400" alt="" /></center><br />
              <center><img src={twenty_eight} width="450" alt="" /></center>
            </>}
            {help === "Копировать код контракта" && <>
              Для того чтобы копировать код контракта выполните следующие действия:<br /><br />
              &nbsp;&nbsp;1. Перейдите во вкладку <span style={{ fontWeight: 'bold' }}>"Контракты"</span> на левой панели, как показано на рисунке ниже;<br /><br />
              <center><img src={three} width="400" alt="" /></center><br />
              &nbsp;&nbsp;2. нажмите на иконку <span style={{ fontWeight: 'bold' }}>“Открыть контракт”</span>, изображенную на рисунке ниже;<br /><br />
              <center><img src={twelve} width="400" alt="" /></center><br />
              &nbsp;&nbsp;3. На правой панели найдите иконку <span style={{ fontWeight: 'bold' }}>"Копировать код"</span>, как показано на рисунке ниже, и щелкните на нее;<br /><br />
              <center><img src={sixteen} width="200" alt="" /></center><br />
              &nbsp;&nbsp;4. В результате код будет скопирован.
            </>}
            {help === "Справка по коду контракта" && <>
              Для того чтобы открыть справку по коду контракта выполните следующие действия:<br /><br />
              &nbsp;&nbsp;1. Перейдите во вкладку <span style={{ fontWeight: 'bold' }}>"Контракты"</span> на левой панели, как показано на рисунке ниже;<br /><br />
              <center><img src={three} width="400" alt="" /></center><br />
              &nbsp;&nbsp;2. нажмите на иконку <span style={{ fontWeight: 'bold' }}>“Открыть контракт”</span>, изображенную на рисунке ниже;<br /><br />
              <center><img src={twelve} width="400" alt="" /></center><br />
              &nbsp;&nbsp;3. На правой панели найдите иконку <span style={{ fontWeight: 'bold' }}>“Справка”</span>, как показано на рисунке ниже, и щелкните на нее;<br /><br />
              <center><img src={fifteen} width="200" alt="" /></center><br />
              &nbsp;&nbsp;4. В результате откроется модальное окно с доступными разделами. Нажмите на нужный раздел, который вам интересен.<br />
              &nbsp;&nbsp;Ниже появится информация, относящаяся к выбранному разделу, как показано на изображении ниже. Вы можете ознакомиться с этой информацией для получения дополнительных сведений или руководства.<br /><br />
              <center><img src={twenty_nine} width="400" alt="" /></center>
            </>}
          </div>}

          {modal_click === "Удалить структуру" && <div>
            <br />
            {todosfive.map((todo) => {
              return (
                <ToDoFive
                  todo={todo}
                  key={todo.id}
                  removeTaskFive={(id, name, e) => removeTaskFive(id, todo.name, "Удалить структуру")} // Pass the structure name
                />
              );
            })}
          </div>}
          {modal_click === "Удалить функцию" && (
            <div>
              <br />
              {todosfive.map((todo) => {
                return (
                  <ToDoFive
                    todo={todo}
                    key={todo.id}
                    removeTaskFive={(id, name, e) => removeTaskFive(id, todo.name, "Удалить функцию")} // Pass the structure name
                  />
                );
              })}
            </div>
          )}

        </Modal>
      </div>
    </>
  );
}

export default Page_2;